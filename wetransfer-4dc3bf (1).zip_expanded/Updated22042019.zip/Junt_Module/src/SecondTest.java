import org.junit.Test;

public class SecondTest {
@Test
public void testReport(){
	System.out.println("Generating JUnit reports.");
}
}
