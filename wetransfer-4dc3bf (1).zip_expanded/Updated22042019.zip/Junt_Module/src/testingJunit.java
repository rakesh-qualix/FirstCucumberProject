import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
//import org.junit.Ignore;
import org.junit.Test;

public class testingJunit {
	@BeforeClass
	public static void seleniumSetU(){
		System.out.println("Initializing the selenium server");
	}
	@Before
	public void testOpenBrowser(){
		System.out.println("Opening Firefox browser");
	}
	@Test
public void testNavigation(){
	System.out.println("Opening the website");
}
	//@Ignore
	@Test
	public void testLoginDetails(){
		System.out.println("Enter login details");
	}
	@After
	public void testCloseBrowser(){
		System.out.println("Closing the firefox browser");
	}
	@AfterClass
	public static void seleniumShutDown(){
		System.out.println("Shutting down selenium server");
	}
}
