package com.easemytripbus.pageObjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Bus_SeatBookingPage {
	WebDriver driver;
	@FindBy(xpath=("//div[@class='normal']"))
	private List<WebElement> chooseChairSeat;
	@FindBy(xpath=("//div[@class='sleeper_normal']"))
	private List<WebElement> chooseSleeperSeat;
	public Bus_SeatBookingPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;

	}
	public boolean visibilityOfSeatClass(WebElement Seat){
		try{
		if(Seat.isDisplayed()){
		return true;
		}
		}catch(Exception e){
			e.printStackTrace();
		
		}
		return false;
	}
	public void chooseSeat(){
		if(chooseChairSeat.size()>0){
		WebElement selectingSeat = chooseChairSeat.get(0);
		
		if(visibilityOfSeatClass(selectingSeat)){
			selectingSeat.click();
		}
		else{
			chooseSleeperSeat.get(0).click();
		}
		}
		else{
			chooseSleeperSeat.get(0).click();
		}
		
		
	}
}
