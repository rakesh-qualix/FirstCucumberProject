package com.easemytripbus.testcases;

import org.testng.annotations.Test;

import com.easemytripbus.generic.BaseLib;
import com.easemytripbus.pageObjects.Bus_BoardingAndDropingPage;
import com.easemytripbus.pageObjects.Bus_ListingPage;
import com.easemytripbus.pageObjects.Bus_SearchPage;
import com.easemytripbus.pageObjects.Bus_SeatBookingPage;

public class TestClass extends BaseLib {
	Bus_SearchPage bsPage;
	Bus_ListingPage blPage;
	Bus_SeatBookingPage bsbPage;
	Bus_BoardingAndDropingPage bbadPage;

	@Test(priority = 1)
	public void busSearching() throws InterruptedException {
		bsPage = new Bus_SearchPage(driver);
		bsPage.sourceCity("Bangalore");
		bsPage.DestCity("Coimbatore");
		bsPage.date();
		bsPage.searchBus();

	}

	@Test(priority = 2)
	public void busListing() throws InterruptedException {
		blPage = new Bus_ListingPage(driver);
		blPage.selectedSectors();
		blPage.clickOnSelectSeat();

	}

	@Test(priority = 3)
	public void seatBooking() {
		bsbPage = new Bus_SeatBookingPage(driver);
		bsbPage.chooseSeat();
	}

	@Test(priority = 4)
	public void boardingAndDroppingPoint() throws InterruptedException {
		bbadPage = new Bus_BoardingAndDropingPage(driver);
		bbadPage.boardingPoint();
		bbadPage.droppingPoint();
		bbadPage.totalFare();
		bbadPage.continueBooking();
	}

}
