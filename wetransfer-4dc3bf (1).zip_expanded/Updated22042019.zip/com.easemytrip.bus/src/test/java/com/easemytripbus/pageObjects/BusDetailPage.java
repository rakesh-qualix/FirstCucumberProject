package com.easemytripbus.pageObjects;

public class BusDetailPage {

}
