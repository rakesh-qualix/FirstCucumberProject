package com.easemytripbus.pageObjects;

import static org.testng.Assert.assertTrue;

import java.util.List;
import java.util.Random;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

import com.easemytripbus.generic.WaitStatementLib;

public class Bus_SearchPage {
	WebDriver driver;
	@FindBy(xpath = ("//input[@placeholder='Source City']"))
	private WebElement src;
	@FindBy(xpath = ("//input[@placeholder='Destination City']"))
	private WebElement dest;
	@FindBy(xpath = ("//input[@id='datepicker']"))
	private WebElement date;
	@FindBy(xpath = ("//table[@class='ui-datepicker-calendar']/tbody/tr/td/a[@href='#']"))
	private List<WebElement> dateList;
	@FindBy(xpath = ("//input[@id='srcbtn']"))
	private WebElement searchBtn;

	public Bus_SearchPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}

	public String sourceCity(String srcCity) throws InterruptedException {
		try {
			assertTrue(src.isDisplayed());
		} catch (Exception e) {
			e.printStackTrace();
		}
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click()", src);
		src.sendKeys(srcCity);

		Thread.sleep(2000);
		try {
			Actions act = new Actions(driver);
			act.sendKeys(Keys.DOWN, Keys.ENTER).build().perform();
			System.out.println("Selected source city is " + " " + srcCity);
			Reporter.log("Selected source city is " + " " + srcCity);
		} catch (Exception e) {
			e.printStackTrace();

		}
		return srcCity;
	}

	public void DestCity(String destCity) throws InterruptedException {

		try {
			assertTrue(dest.isDisplayed());
		} catch (Exception e) {
			e.printStackTrace();
		}
		dest.sendKeys(destCity);
		Thread.sleep(2000);
		dest.sendKeys(Keys.ARROW_DOWN, Keys.ENTER);
		System.out.println("Selected destination city is " + " " + destCity);
		Reporter.log("Selected destination city is " + " " + destCity);
	}

	public void date() {
		try {
			assertTrue(date.isDisplayed());
		} catch (Exception e) {
			e.printStackTrace();
		}

		Random date = new Random();
		int availableDateSize = date.nextInt(dateList.size());
		WebElement choosenDate = dateList.get(availableDateSize);
		choosenDate.click();
		System.out.println("Selected booking date is " + " " + choosenDate.getAttribute("textContent") + "-" + "April"
				+ "-" + "2019");
		Reporter.log("Selected date is " + " " + choosenDate.getText() + "-" + "April" + "-" + "2019");
	}

	public void searchBus() {
		try {
			assertTrue(searchBtn.isDisplayed());
		} catch (Exception e) {
			e.printStackTrace();
		}

		searchBtn.click();
		WaitStatementLib.iWait(2);
		System.err.println("Please Wait, We Are Searching a best Bus for you!!!");
		Reporter.log("Please Wait, We Are Searching a best Bus for you!!!");
	}
}
