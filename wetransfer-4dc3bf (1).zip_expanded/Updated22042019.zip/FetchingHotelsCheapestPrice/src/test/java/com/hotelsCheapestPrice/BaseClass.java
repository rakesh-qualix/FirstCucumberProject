package com.hotelsCheapestPrice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class BaseClass {
	public WebDriver driver;

	@BeforeTest
	public void setUp() throws InterruptedException {
		/*driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("https://hotel.easemytrip.com/");*/
		//Create a instance of ChromeOptions class
		ChromeOptions options = new ChromeOptions();
		//Add chrome switch to disable notification - "**--disable-notifications**"
		options.addArguments("--disable-notifications");
		System.setProperty("webdriver.chrome.driver","D:\\EasemytripFlightProject\\FetchingHotelsCheapestPrice\\Driver\\chromedriver.exe");
		driver=new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.get("https://hotel.easemytrip.com/");
		Thread.sleep(1000);
	}

	@AfterTest
	public void closingConnection() throws InterruptedException {
		Thread.sleep(10000);
		driver.close();
	}
}
