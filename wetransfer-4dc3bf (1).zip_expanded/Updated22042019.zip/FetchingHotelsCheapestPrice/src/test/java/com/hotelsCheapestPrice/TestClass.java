package com.hotelsCheapestPrice;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.annotations.Test;

public class TestClass extends BaseClass{
	HotelCheapestPrice hotel;
@Test(priority=1)
public void Hotel() throws EncryptedDocumentException, InvalidFormatException, TimeoutException, IOException, InterruptedException{
	hotel=new HotelCheapestPrice(driver);
	hotel.hotelSearching();
}
}
