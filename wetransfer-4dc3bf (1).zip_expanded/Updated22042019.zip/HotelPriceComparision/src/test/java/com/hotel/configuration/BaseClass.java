package com.hotel.configuration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class BaseClass {
	public WebDriver driver;

	@BeforeTest
	public void setUp() throws InterruptedException {
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("https://hotel.easemytrip.com/");
		Thread.sleep(5000);
	}

	@AfterTest
	public void closingCionnection() throws InterruptedException {
		Thread.sleep(10000);
		driver.close();
	}
}
