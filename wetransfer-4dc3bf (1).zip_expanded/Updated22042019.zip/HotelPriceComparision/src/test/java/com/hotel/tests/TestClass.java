package com.hotel.tests;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.annotations.Test;

import com.hotel.configuration.BaseClass;
import com.hotel.pageObjects.Hotel;

public class TestClass extends BaseClass{
Hotel hotel;
@Test(priority=1)
public void Hotel() throws EncryptedDocumentException, InvalidFormatException, TimeoutException, IOException, InterruptedException{
	hotel=new Hotel(driver);
	hotel.hotelReading();
}
}
