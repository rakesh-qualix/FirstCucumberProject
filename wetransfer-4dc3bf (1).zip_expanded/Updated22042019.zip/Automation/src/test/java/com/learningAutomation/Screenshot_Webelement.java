package com.learningAutomation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.coordinates.WebDriverCoordsProvider;
import javax.imageio.ImageIO;
import java.io.File;

public class Screenshot_Webelement {

	public static void main(String[] args)  throws Exception{
		
		System.setProperty("webdriver.chrome.driver","D:\\EasemytripFlightProject\\Automation\\Drivers\\chromedriver.exe");	
		WebDriver driver = new ChromeDriver(); 
		driver.get("http://www.google.com");
		Thread.sleep(2000);
		System.out.println(driver.getTitle());
		WebElement webElement = driver.findElement(By.xpath("//canvas[@id='hpcanvas']"));
		//WebElement webElement = driver.findElement(By.xpath("//div[@class='gb_Ja gb_qg gb_f gb_pg gb_tg gb_If']"));
		Screenshot screenshot = new AShot().coordsProvider(new WebDriverCoordsProvider()).takeScreenshot(driver, webElement);
		ImageIO.write(screenshot.getImage(),"PNG",new File(System.getProperty("user.dir") +"\\Images\\googleLogo.png"));
		driver.close();
	}

}
