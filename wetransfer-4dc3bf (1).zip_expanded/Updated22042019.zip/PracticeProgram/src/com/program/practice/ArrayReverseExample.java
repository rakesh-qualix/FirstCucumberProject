package com.program.practice;

import java.util.Arrays;

//How To Reverse An Array In Java?
/*Step 1 : Let inputArray be the given array.

Step 2 : Iterate over only half of the inputArray (inputArray.length / 2). For every ith element, swap it with (inputArray.length-1-i)th element.
Step 3 : Print inputArray.
*/
public class ArrayReverseExample {
static void reverseArray(int inputArray[]){
	 System.out.println("Array Before Reverse : "+Arrays.toString(inputArray));
	 int temp;
	 for(int i=0;i<inputArray.length/2;i++){
		 temp=inputArray[i];
		 inputArray[i]=inputArray[inputArray.length-1-i];
		 inputArray[inputArray.length-1-i] = temp;
	 }
	 System.out.println("Array After Reverse : "+Arrays.toString(inputArray));
}
	public static void main(String[] args) {
reverseArray(new int[]{4, 5, 8, 9, 10});
        
        System.out.println("-------------------------");

	}

}
