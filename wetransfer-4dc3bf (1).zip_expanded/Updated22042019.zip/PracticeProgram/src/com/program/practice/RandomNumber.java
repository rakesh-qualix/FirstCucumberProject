package com.program.practice;

import java.util.Random;

public class RandomNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 // create random object 
        Random ran = new Random(); 
  
        // Print next int value 
        // Returns number between 0-10 
        int nxt = ran.nextInt(10); 
  
        // Printing the random number between 0 and 10 
        System.out.println("Random number between 0 and 10 is : " + nxt); 
    } 
	}


