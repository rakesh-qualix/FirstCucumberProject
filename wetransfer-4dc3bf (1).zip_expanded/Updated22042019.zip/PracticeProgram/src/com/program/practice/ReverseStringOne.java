package com.program.practice;

public class ReverseStringOne {

	public static void main(String[] args) {
		/*StringBuffer sbf = new StringBuffer("EaseMyTrip");
		StringBuffer reversedString = sbf.reverse();
		System.out.println("Reverse String is :" + reversedString);*/
		String str="EaseMyTrip";
		char[] strArray = str.toCharArray();
		for(int i=str.length()-1;i>0;i--){
			System.out.print(strArray[i]);
		}
	}

}
