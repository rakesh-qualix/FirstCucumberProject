package com.program.practice;

import java.util.ArrayList;
import java.util.HashSet;

//Removing Duplicate Elements From ArrayList Using HashSet
public class RemovingDuplicateElementsFromArrayList {

	public static void main(String[] args) {
		//Constructing an ArrayList
		ArrayList<String> listWithDuplicatesValue=new ArrayList<String>();
		//Adding elements to ArrayList
		listWithDuplicatesValue.add("JAVA");
		listWithDuplicatesValue.add("J2EE");
		listWithDuplicatesValue.add("JSP");
		listWithDuplicatesValue.add("SERVLET");
		listWithDuplicatesValue.add("JAVA");
		listWithDuplicatesValue.add("SERVLET");
		listWithDuplicatesValue.add("SPRING");
		listWithDuplicatesValue.add("JSP");

//Printing listWithDuplicatesValue
		System.out.println(listWithDuplicatesValue);
		//Constructing HashSet using listWithDuplicatesValue
		HashSet<String> set=new HashSet<String>(listWithDuplicatesValue);
	//	ArrayList<String> listWithoutDuplicateElements = new ArrayList<String>(set);
		System.out.print("ArrayList After Removing Duplicate Elements :");
		System.out.println(set);
		//System.out.println(listWithoutDuplicateElements);
	}

}
