package com.program.practice;

public class ReverseEachWord {

	static void reverseEachWordOfString(String inputString){
		//split given String into words
		String[] word = inputString.split("\\ ");
		String reverseString="";
		for(int i=0;i<word.length;i++){
			//Taking each word and reversing it
			String words=word[i];
			String reverseWord="";
			for(int j=words.length()-1;j>=0;j--){
				reverseWord=reverseWord+words.charAt(j);
			}
			//Appending reverseWord to reverseString
			reverseString = reverseString + reverseWord + " ";
		}
		
		 System.out.println(inputString);
	    //Finally print reverse String    
	        System.out.println(reverseString);
	        
	        System.out.println("-------------------------");
	}
	public static void main(String[] args) {
		 reverseEachWordOfString("Java Concept Of The Day");
	        
	        reverseEachWordOfString("Java J2EE JSP Servlets Hibernate Struts");
	        
	        reverseEachWordOfString("I am string not reversed");
	        
	        reverseEachWordOfString("Reverse Me");

	}

}
