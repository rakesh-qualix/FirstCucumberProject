package com.program.practice;

abstract class Abstraction {
	abstract int getROI();

	int p, r, t;
	double SI;

	public double getSI() {
		SI = p * r * t / 100;
		return SI;
	}

	public int getP() {
		return p;
	}

	public void setP(int p) {
		this.p = p;
	}

	public int getR() {
		return r;
	}

	public void setR(int r) {
		this.r = r;
	}

	public int getT() {
		return t;
	}

	public void setT(int t) {
		this.t = t;
	}

}

class SBI1 extends Abstraction {

	@Override
	int getROI() {

		return 10;
	}

}

class ICICI1 extends Abstraction {

	@Override
	int getROI() {

		return 14;
	}

}

class TestOne {
	public static void main(String[] args) {
		Abstraction ab;
		ab = new SBI1();
		ab.getROI();
		System.out.println("Interest rate of SBI : " + ab.getROI() + "%");
		ab.setP(1000);
		ab.setR(5);
		ab.setT(2);
		ab.getSI();
		System.out.println("Interest  of ICICI : " + ab.getSI());
		ab = new ICICI1();
		ab.getROI();
		System.out.println("Interest rate of ICICI : " + ab.getROI() + "%");
	}
}