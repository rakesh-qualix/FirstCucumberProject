package com.program.practice;

public class Student {
private String name;
public String getName(){
	return name;
	
}
public void setName(String name){
	this.name=name;
}
	public static void main(String[] args) {
		
Student st=new Student();
st.setName("Rakesh");
st.getName();
System.out.println("Name of the Student is : "+st.getName());
	}

}
