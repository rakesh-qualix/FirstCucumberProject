package com.program.practice;

class Calculation {
	  private  int z;
		
	   public void addition(int x, int y) {
	      //setZ(x + y);
		   z=x+y;
				   
	     System.out.println("The sum of the given numbers:"+getZ());
		  // System.out.println("The sum of the given numbers:"+z);
	   }
		
	   public void Subtraction(int x, int y) {
	    //  setZ(x - y);
		   z=x-y;
	      System.out.println("The difference between the given numbers:"+getZ());
		   //System.out.println("The difference between the given numbers:"+z);
	   }

	public int getZ() {
		return z;
	}

	public void setZ(int z) {
		this.z = z;
	}
	}


	public class My_Calculation extends Calculation {
	   public void multiplication(int x, int y) {
	     setZ(x * y);
		 //  z=x*y;
	      System.out.println("The product of the given numbers:"+getZ());
	   }
		
	   public static void main(String args[]) {
	      int a = 20, b = 10;
	      My_Calculation demo = new My_Calculation();
	      demo.addition(a, b);
	      demo.Subtraction(a, b);
	      demo.multiplication(a, b);
	   }
	}
