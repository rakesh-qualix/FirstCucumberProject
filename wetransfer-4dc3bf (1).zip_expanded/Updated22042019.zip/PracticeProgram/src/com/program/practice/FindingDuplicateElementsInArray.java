package com.program.practice;

import java.util.HashSet;

//Java Program To Find Duplicate Elements In An Array Using HashSet 
public class FindingDuplicateElementsInArray {

	public static void main(String[] args) {
		String[] strArray={"Rakesh","Chandeep","Abhishek","Rakesh","Sunil","Chandeep","Sunil"};
		HashSet<String> set=new HashSet<String>();
		for(String arrayElement:strArray){
			//To find Duplicate elements in array
			/*if(!set.add(arrayElement)){
				 System.out.println("Duplicate Element is : "+arrayElement);*/
				//To remove element from array
			if(set.add(arrayElement)){
				 System.out.println("Element after removing duplicate Element is : "+arrayElement);
			}
			
		}

	}

}
