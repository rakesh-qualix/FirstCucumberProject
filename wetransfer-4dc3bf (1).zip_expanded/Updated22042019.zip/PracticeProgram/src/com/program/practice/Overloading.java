package com.program.practice;

public class Overloading {
	void sum(int a, int b) {
		System.out.println("Sum of a and b are : " + (a + b));
	}
//method overloading
	void sum(int a, int b, int c) {
		System.out.println("Sum of a,b and c are :=" + (a + b + c));
	}

	public static void main(String[] args) {
		Overloading o1 = new Overloading();
		o1.sum(10, 20);
		o1.sum(20, 30, 50);

	}

}
