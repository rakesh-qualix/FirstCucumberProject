package com.program.practice;

public class BankDetails {
private long acc_no;
private String name,email;
private float acc_balance;
public long getAcc(){
	return acc_no;
}
public String getName(){
	return name;
}

public String getEmail(){
	return email;
}
public float getAcc_Bal(){
	return acc_balance;
}
public void setAcc_no(long acc_no){
	this.acc_no=acc_no;
}
public void setName(long acc_no){
	this.acc_no=acc_no;
}
public void setName(String name){
	this.name=name;
}
public void setEmail(String email){
	this.email=email;
}
public void setAcc_Bal(float acc_balance){
	this.acc_balance=acc_balance;
}

	public static void main(String[] args) {
		BankDetails bd=new BankDetails();
		bd.setAcc_no(2002373663);
		bd.getAcc();
		bd.setName("Rakesh Jha");
		bd.getName();
		bd.setEmail("kumar.rakesh1@in.easemytrip.com");
		bd.getEmail();
		bd.setAcc_Bal(500000);
		bd.getAcc_Bal();
		System.out.print("Account Details are : \n"+"Account Number : "+bd.getAcc()+"\n"+"Account Name : "+bd.getName()+"\n"+"Email : "+bd.getEmail()+"\n"+"Available Account Balance is : "+bd.getAcc_Bal());
	}

}
