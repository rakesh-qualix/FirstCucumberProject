package com.program.practice;

public class Swap {

private int a,b,temp;

	public int getA() {
	return a;
}

public void setA(int a) {
	this.a = a;
}

public int getB() {
	return b;
}

public void setB(int b) {
	this.b = b;
}


public void beforeSwap(){
	System.out.println("Before swapping a and b are : "+a+"  "+b);
}
public void afterSwap(){
	a=a+b;
	b=a-b;
	a=a-b;
	/*temp=a;
	a=b;
	b=temp;*/
	System.out.println("After swapping a and b are : "+a+"  "+b);
}

	public static void main(String[] args) {
		
Swap sw=new Swap();
sw.setA(40);
sw.getA();
sw.setB(100);
sw.getB();
sw.beforeSwap();
sw.afterSwap();
	}

}
