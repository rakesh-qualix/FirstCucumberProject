package com.PracticeOne;

public class SwaapingNoUsingThirdVariable {
	private int a, b, temp;

	public int getA() {
		return a;
	}

	public int getB() {
		return b;
	}

	public void setA(int a) {
		this.a = a;
	}

	public void setB(int b) {
		this.b = b;

	}

	public void beforeSwap() {
		System.out.println("Before Swapping :" + a + " " + b);
	}

	/**
	 *Swapping two numbers without using third variables 
	 */
	/**
	 * Swapping two numbers  using third variables 
	 */
	public void afterSwap() {
		a=a+b;
		b=a-b;
		a=a-b;
		/*temp = a;
		a = b;
		b = temp;*/
		System.out.println("After Swapping :" + a + " " + b);
	}

	public static void main(String[] args) {
		SwaapingNoUsingThirdVariable sw = new SwaapingNoUsingThirdVariable();
		sw.setA(25);
		sw.getA();
		sw.setB(23);
		sw.beforeSwap();
		sw.afterSwap();
	}

}
