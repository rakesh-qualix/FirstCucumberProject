package com.PracticeOne;

import java.util.HashSet;

public class RemoveDuplicate {

	public static void main(String[] args) {
		String[] str = { "Rakesh", "Rajesh", "Rupesh", "Chandeep", "Rakesh", "Chandeep" };
		HashSet<String> set = new HashSet<String>();
		for (String str1 : str) {
			if (!set.add(str1)){
				
			System.out.println("Element after removing duplicate Element is : " + str1);
		}
	}
	}
}


