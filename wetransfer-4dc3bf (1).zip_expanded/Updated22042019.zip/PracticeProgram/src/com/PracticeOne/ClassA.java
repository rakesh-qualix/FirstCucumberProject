package com.PracticeOne;

public class ClassA {

	public static void main(String[] args) {
		byte i=10;
		byte j=20;
		byte k=(byte) (i+j);
		System.out.println(k);
		

	}

}
