package practiceprogram;

import java.util.Scanner;

public class RemoveWhiteSpace {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter input String to be cleaned from White Space!!! ");
		String inputString = sc.nextLine();
		String stringWithoutSpaces = inputString.replaceAll("\\s+",  "");
		System.out.println("Input String :"+inputString);
		System.out.println("Input String without spaces : "+stringWithoutSpaces);
	}

}
