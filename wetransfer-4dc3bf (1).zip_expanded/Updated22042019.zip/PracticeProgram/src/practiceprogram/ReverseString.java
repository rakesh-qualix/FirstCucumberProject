package practiceprogram;

public class ReverseString {

	public static void main(String[] args) {
		/*StringBuffer sbf = new StringBuffer("Easemytrip");
		System.out.println("Reverse String is : "+sbf.reverse());*/
		//Using Iterative
		String str="Easemytrip";
		char[] str1 = str.toCharArray();
		for(int i=str1.length-1;i>=0;i--){
			System.out.println(str1[i]);
		}
	}

}
