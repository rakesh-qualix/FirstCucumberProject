package practiceprogram;

import java.awt.PageAttributes.OriginType;
import java.util.Scanner;

public class ReverseStringOne {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter a String Which you want to reverse!!!");
	StringBuffer sb=new StringBuffer(sc.nextLine());
	StringBuffer reverse = sb.reverse();
	System.out.println(reverse);
	/*String orginal = sc.nextLine();
	int length = orginal.length();
	for(int i=length-1;i>=0;i--){
		char reverse = orginal.charAt(i);
		System.out.print(reverse);
	}*/

	}

}
