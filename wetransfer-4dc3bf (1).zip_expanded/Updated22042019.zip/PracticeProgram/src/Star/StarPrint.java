package Star;

public class StarPrint {

	public static void main(String[] args) {
		/*int i;
		for(i=5;i>=1;i--){
			System.out.println("*");
		}
*/
		int i ,j;
		//Outer loop for rows
		for(i=1;i<=4;i++){
			//Inner loop for column
			for(j=1;j<=5;j++){
				System.out.print("*");
			}
			System.out.println(" ");
		}
	}

}
