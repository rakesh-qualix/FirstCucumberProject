package com.emtHotel.objects;

import java.util.List;
import java.util.Random;
import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class HotelListingPage {
	WebDriver driver;

	@FindBy(xpath = ("//div[@id='hotelListDiv']/div/div/div"))
	private List<WebElement> hotelList;
	@FindBy(xpath = ("//span[@id='htlTotal']"))
	private WebElement totalNoOfHoteFound;
	@FindBy(xpath=("//div[@class='llp']"))
	private List<WebElement> hotelDetails;


	public HotelListingPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}

	@Test
	public void hotelListing() {

		String totalHotel = totalNoOfHoteFound.getText();
		int noOfHotel = Integer.parseInt(totalHotel);
		Reporter.log("The total number of hotel found " + " " + noOfHotel);
		try {
			for (int i = hotelList.size(); i < 60; i++) {
				//Thread.sleep(2000);
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("window.scrollBy(0,document.body.scrollHeight)");// Dynamic scrolling
				Thread.sleep(1000);
				if (hotelList.size() > 60) {
					Reporter.log("The total number of hotel taken in list is " + " " + hotelList.size());
					System.out.println("Total hotel found is " + " " + noOfHotel);
					break;
				}
			}
			//Thread.sleep(2000);
			Random selectedHotel = new Random();
			int randomHotelSelection = selectedHotel.nextInt(hotelList.size());
			
			WebElement selectedHotelFromList = hotelList.get(randomHotelSelection);
			
			Thread.sleep(1000);
			String fetchingHotelsDetails = hotelDetails.get(randomHotelSelection).getText();
			//String hotelName = selectedHotelFromList.getText();
			//Reporter.log("Selected Hotel Details are "+" "+hotelName);
			System.err.println(fetchingHotelsDetails);
			Reporter.log("Selected Hotel Details are "+" "+fetchingHotelsDetails);
			//System.out.println(hotelName);
			JavascriptExecutor js = (JavascriptExecutor) driver;
	        //use executeScript() method and pass the arguments 
	        //Here i pass values based on css style. Yellow background color with solid red color border. 
			js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", selectedHotelFromList);
			Thread.sleep(8000);
			selectedHotelFromList.click();
			Thread.sleep(5000);
			Reporter.log("Hotel is selected, Please Wait!!! Booking Details will be shown on next Page!!!");

		} catch (InterruptedException e) {

			e.printStackTrace();
		}

	}

	@Test(dependsOnMethods="hotelListing")
	public void bookingDetails() throws InterruptedException {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e2) {

			e2.printStackTrace();
		}

		// Script For Window Handling
		Set<String> windowsId = driver.getWindowHandles();
		String firstWinHandle = driver.getWindowHandle();
		windowsId.remove(firstWinHandle);
		String winHandleId = windowsId.iterator().next();
		if (winHandleId != firstWinHandle) {
			String secondWinHandleId = winHandleId;
			driver.switchTo().window(secondWinHandleId);
		}

		Thread.sleep(2000);
		List<WebElement> bookingDetails = driver
				.findElements(By.xpath("//form[@id='myDescForm']/div[7]/article/div[2]/div[2]/div/div[position()>1]"));
		int sizeofBookingField = bookingDetails.size();
		String bookingSummaryDetails = null;

		for (int i = 0; i < sizeofBookingField; i++) {
			WebElement bookingSummary = bookingDetails.get(i);
			if (i == 2) {
				Select sel = new Select(driver.findElement(By.xpath("//select[@id='ddlRoomSelect']")));
				WebElement dropdownOption = sel.getFirstSelectedOption();
				String roomType = dropdownOption.getText();
				Reporter.log("Selected Room Type is " + " " + ":" + roomType);
				System.out.println(roomType);
			} else if (i == 0) {
				bookingSummaryDetails = bookingSummary.getAttribute("textContent");
				Reporter.log("Booking Hotel For " + " " + ":" +bookingSummaryDetails);
				System.out.print( bookingSummaryDetails);
			} else if (i == 1) {
				bookingSummaryDetails = bookingSummary.getAttribute("textContent");
				Reporter.log("Check_In and Check_out Date is  " + " " + ":" + bookingSummaryDetails);
				System.out.print(bookingSummaryDetails);
			}
		}

		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}

	@Test(dependsOnMethods="bookingDetails")
	public void bookNow() {
		WebElement bookBtn = driver.findElement(By.xpath("//div[@class='wid_full_n']/div"));
		bookBtn.click();
		Reporter.log("Successfully clicked on Book Now Button!!!");
		
	}

}
