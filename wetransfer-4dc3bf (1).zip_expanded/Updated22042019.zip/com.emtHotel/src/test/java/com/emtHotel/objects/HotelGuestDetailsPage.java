package com.emtHotel.objects;

//import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
//import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class HotelGuestDetailsPage {
	WebDriver driver;
	@FindBy(xpath = ("//div[@class='noofAdult ng-scope']/div[position()>2]/input"))
	private List<WebElement> guestSectors;
	@FindBy(xpath = ("//input[@id='txtEmailId']"))
	private WebElement guestEmail;
	@FindBy(xpath = ("//input[@id='txtCPhone']"))
	private WebElement guestMobile;
	@FindBy(xpath=("//input[@id='chkAgree1']"))
	private WebElement chkBox;
	@FindBy(xpath = ("//div[@class='coonpayment']"))
	private WebElement continueToPaymentBtn;
	@FindBy(xpath=("//div[@class='hotelrvw-info']"))
	private WebElement HotelDetails;
	@FindBy(xpath=("//div[@id='sidebar']/div[1]"))
	private WebElement roomFareDetails;
	public HotelGuestDetailsPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}
/*@Test
public void hotelDetails(){
	String bookingDetails = HotelDetails.getAttribute("textContent");
	Reporter.log("Booking Details are "+" "+bookingDetails);
	
	}*/
	@Test
	public void guestDetails() {
		int sizeOfGuest = guestSectors.size();
		
		/*
		 * List<String> firstName=new ArrayList<String>();
		 * firstName.add("Rakesh"); firstName.add("Chandeep"); List<String>
		 * lastName= new ArrayList<String>(); lastName.add("Jha");
		 * lastName.add("Ahluwalia");
		 */

		for (int g = 0; g < sizeOfGuest; g++) {
			WebElement guest = guestSectors.get(g);
			JavascriptExecutor js = (JavascriptExecutor) driver;
		    //use executeScript() method and pass the arguments 
		    //Here i pass values based on css style. Yellow background color with solid red color border. 
			js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", guest);
			guest.click();
			
			guest.sendKeys("Test");

		}

	}

	@Test
	public void guestContact() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
	    //use executeScript() method and pass the arguments 
	    //Here i pass values based on css style. Yellow background color with solid red color border. 
		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", guestEmail);
		guestEmail.click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		guestEmail.sendKeys("test@test.com");
		Reporter.log("Guest Email address is " + " " + ":" + "test@test.com");
		JavascriptExecutor js1 = (JavascriptExecutor) driver;
	    //use executeScript() method and pass the arguments 
	    //Here i pass values based on css style. Yellow background color with solid red color border. 
		js1.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", guestMobile);
		guestMobile.click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		guestMobile.sendKeys("9896586969");
		Reporter.log("Guest Mobile Number is " + " " + ":" + "9896586969");
		chkBox.click();
		continueToPaymentBtn.click();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	@Test
	public void fareDetails(){
		String FareBreakup = roomFareDetails.getText();
		//String FareBreakup = roomFareDetails.getAttribute("textContent");
		Reporter.log("Room Fare Details are: "+FareBreakup);
	}

}
