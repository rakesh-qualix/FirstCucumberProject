import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class test_1 {
	@Test
public void testLogin(){
	System.out.println("Testing Login Screen");
}
	@Test
	public void testForm(){
		System.out.println("Testing Registration Form");
	}
	@BeforeMethod
	public void openBrowser(){
		System.out.println("Opening Browser");
	}
	@AfterMethod
	public void closeBrowser(){
		System.out.println("Closing Browser");
	}
	@BeforeTest
	public void openDbConnection(){
		System.out.println("Create Db Connection");
	}
	@AfterTest
	public void closeDbConnection(){
		System.out.println("Closing Db Connection");
	}
	@BeforeSuite
	public void runSeleniumServer(){
		System.out.println("Starting Selenium Server");
	}
	@AfterSuite
	public void stopSeleniumServer(){
		System.out.println("Stop selenium server");
	}
	}
