import org.testng.annotations.Test;

public class test_2 {
@Test
public void testCaptureScreen(){
	System.out.println("Capturing screen test");
}
}
