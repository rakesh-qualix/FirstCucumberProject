package com.easemytripbus.pageObjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

public class Bus_BoardingAndDropingPage {
	WebDriver driver;
	@FindBy(xpath = ("//div[@class='right_col']/div/ul/li"))
	private List<WebElement> boardingAndDropingPoint;
	@FindBy(xpath = ("//div[@id='myModal']/div/div[2]/div/ul/li/ul/li[@ng-repeat='list in seatlist.listBoardingPoint']"))
	private List<WebElement> boardingPointOptions;
	@FindBy(xpath = ("//div[@id='myModal']/div/div[2]/div/ul/li/ul/li[@ng-repeat='list in seatlist.listDropingPoint']"))
	private List<WebElement> droppingPointOPtions;
	@FindBy(xpath = ("//span[@class='b_fare fltr ng-binding']"))
	private WebElement totalFare;
	@FindBy(xpath = ("//a[@class='btn_cntn']"))
	private WebElement continueBtn;

	public Bus_BoardingAndDropingPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;

	}

	public void boardingPoint() throws InterruptedException {
		WebElement boarding = boardingAndDropingPoint.get(0);
		boarding.click();
		// Thread.sleep(2000);
		if (boardingPointOptions.size() == 1) {
			WebElement boardingPoint = boardingPointOptions.get(0);
			// Thread.sleep(1000);
			boardingPointOptions.get(0).click();
			// Thread.sleep(1000);
			Reporter.log("Selected Boarding Point is " + " " + boardingPoint.getAttribute("textContent"));
			System.out.println("Selected Boarding Point is " + " " + boardingPoint.getAttribute("textContent"));
		} else {
			WebElement boardingPoint = boardingPointOptions.get(1);
			// Thread.sleep(1000);
			boardingPointOptions.get(1).click();
			// Thread.sleep(1000);
			Reporter.log("Selected Boarding Point is " + " " + boardingPoint.getAttribute("textContent"));
			System.out.println("Selected Boarding Point is " + " " + boardingPoint.getAttribute("textContent"));
		}
		// Reporter.log("Selected Boarding Point is " + " " +
		// boardingPoint.getAttribute("textContent"));
		// System.out.println("Selected Boarding Point is " + " " +
		// boardingPoint.getAttribute("textContent"));

	}

	public void droppingPoint() throws InterruptedException {
		WebElement droping = boardingAndDropingPoint.get(1);
		droping.click();
		// Thread.sleep(2000);
		if (droppingPointOPtions.size() == 1) {
			WebElement dropingPoint = droppingPointOPtions.get(0);
			// Thread.sleep(2000);
			droppingPointOPtions.get(0).click();
			// Thread.sleep(1000);
			Reporter.log("Selected droping Point is " + " " + dropingPoint.getAttribute("textContent"));
			System.out.println("Selected droping Point is " + " " + dropingPoint.getAttribute("textContent"));
		} else {
			WebElement dropingPoint = droppingPointOPtions.get(1);
			// Thread.sleep(2000);
			droppingPointOPtions.get(1).click();
			// Thread.sleep(1000);
			Reporter.log("Selected droping Point is " + " " + dropingPoint.getAttribute("textContent"));
			System.out.println("Selected droping Point is " + " " + dropingPoint.getAttribute("textContent"));
		}
		// WebElement dropingPoint = droppingPointOPtions.get(1);
		// Thread.sleep(2000);
		// droppingPointOPtions.get(1).click();
		// Thread.sleep(1000);
		// Reporter.log("Selected droping Point is " + " " +
		// dropingPoint.getAttribute("textContent"));
		// System.out.println("Selected droping Point is " + " " +
		// dropingPoint.getAttribute("textContent"));

	}

	public void totalFare() {
		Reporter.log("Fare for this booking is " + " " + totalFare.getText());
		System.out.println("Fare for this booking is " + " " + totalFare.getText());
	}

	public void continueBooking() throws InterruptedException {
		continueBtn.click();
		Thread.sleep(5000);
	}
}
