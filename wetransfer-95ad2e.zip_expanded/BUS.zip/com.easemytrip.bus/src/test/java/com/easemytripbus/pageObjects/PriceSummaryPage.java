package com.easemytripbus.pageObjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

public class PriceSummaryPage {
	WebDriver driver;
	@FindBy(xpath = ("//div[@class='prm']/div"))
	private List<WebElement> priceSummary;

	public PriceSummaryPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;

	}

	public void priceDetails() {
		Reporter.log("Fare Breakup Details are: " + " ");
		System.out.println("Fare Breakup Details are: " + " ");
		for (int p = 0; p < priceSummary.size(); p++) {
			String fareBreakupDetails = priceSummary.get(p).getText();
			Reporter.log(fareBreakupDetails);
			System.out.println(fareBreakupDetails);
		}
		System.out.println("==================================================");
	}
}
