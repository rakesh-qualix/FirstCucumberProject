package com.easemytripbus.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

public class CouponCodePage {
	WebDriver driver;
	@FindBy(xpath = ("//input[@placeholder='Enter Coupon Code']"))
	private WebElement couponCode;
	@FindBy(xpath = ("//div[@class='apl']"))
	private WebElement applyBtn;
	@FindBy(xpath = ("//input[@disabled='disabled']"))
	private WebElement checkCouponAvailable;

	public CouponCodePage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;

	}

	public boolean isCouponAvailable(WebElement checkCouponAvailable) {
		try {
			if (checkCouponAvailable.isDisplayed()) {
				return true;
			}
		} catch (Exception e) {
			return false;
			// e.printStackTrace();
		}
		return false;

		// return false;

	}

	public void couponCode(String coupon) throws InterruptedException {
		Thread.sleep(2000);
		if (isCouponAvailable(checkCouponAvailable)) {
			System.err.println("Coupon Code is not applicable on RTC's buses.");
			System.out.println("===============================================");
			Reporter.log("Coupon Code is not applicable on RTC's buses.");
		} else {
			Reporter.log("Applied coupons are " + " " + coupon);
			couponCode.sendKeys(coupon);
			Thread.sleep(1000);
			applyBtn.click();
			Thread.sleep(1000);
		}

	}
}
