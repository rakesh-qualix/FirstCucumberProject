package com.easemytripbus.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ContactDetailsPage {
	WebDriver driver;
	@FindBy(xpath="//input[@placeholder='Enter your Email ID']")
	private WebElement travelerEmail;
	@FindBy(xpath=("//span[@class='co']"))
	private WebElement continueBtn;
	public ContactDetailsPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;

	}
	public void email() throws InterruptedException{
		travelerEmail.sendKeys("tech@easemytrip.com");
		Thread.sleep(1000);
	}
	public void clickOnContinue(){
		continueBtn.click();
	}
}
