package com.easemytripbus.testcases;

import org.testng.annotations.Test;

import com.easemytripbus.generic.BaseLib;
import com.easemytripbus.pageObjects.BusDetailPage;
import com.easemytripbus.pageObjects.Bus_BoardingAndDropingPage;
import com.easemytripbus.pageObjects.Bus_ListingPage;
import com.easemytripbus.pageObjects.Bus_PaymentPage;
import com.easemytripbus.pageObjects.Bus_SearchPage;
import com.easemytripbus.pageObjects.Bus_SeatBookingPage;
import com.easemytripbus.pageObjects.ContactDetailsPage;
import com.easemytripbus.pageObjects.CouponCodePage;
import com.easemytripbus.pageObjects.PriceSummaryPage;
import com.easemytripbus.pageObjects.TravellerBookedDetailsPage;
import com.easemytripbus.pageObjects.TravellerDetailsPage;

public class TestClass extends BaseLib {
	Bus_SearchPage bsPage;
	Bus_ListingPage blPage;
	Bus_SeatBookingPage bsbPage;
	Bus_BoardingAndDropingPage bbadPage;
	BusDetailPage bdPage;
	PriceSummaryPage psPage;
	CouponCodePage ccPage;
	ContactDetailsPage cdPage;
	TravellerDetailsPage tdPage;
	TravellerBookedDetailsPage tbdPage;
	Bus_PaymentPage bppPage;

	@Test(priority = 1)
	public void busSearching() throws InterruptedException {
		bsPage = new Bus_SearchPage(driver);
		bsPage.sourceCity();
		bsPage.DestCity();
		// bsPage.sourceCity("Delhi");
		// bsPage.DestCity("Haridwar");
		bsPage.date();
		bsPage.searchBus();

	}

	@Test(priority = 2)
	public void busListing() throws InterruptedException {
		blPage = new Bus_ListingPage(driver);
		blPage.selectedSectors();
		blPage.clickOnSelectSeat();

	}

	@Test(priority = 3)
	public void seatBooking() throws InterruptedException {
		bsbPage = new Bus_SeatBookingPage(driver);
		bsbPage.chooseSeat();
	}

	@Test(priority = 4)
	public void boardingAndDroppingPoint() throws InterruptedException {
		bbadPage = new Bus_BoardingAndDropingPage(driver);
		bbadPage.boardingPoint();
		bbadPage.droppingPoint();
		bbadPage.totalFare();
		bbadPage.continueBooking();
	}

	@Test(priority = 5)
	public void busDetails() {
		bdPage = new BusDetailPage(driver);
		bdPage.findingBusDetails();
	}

	@Test(priority = 6)
	public void appliedCoupon() throws InterruptedException {
		ccPage = new CouponCodePage(driver);
		ccPage.couponCode("BUS10");
	}

	@Test(priority = 7)
	public void priceSummary() {
		psPage = new PriceSummaryPage(driver);
		psPage.priceDetails();
	}

	@Test(priority = 8)
	public void contactDetails() throws InterruptedException {
		cdPage = new ContactDetailsPage(driver);
		cdPage.email();
		cdPage.clickOnContinue();
	}

	@Test(priority = 9)
	public void selectedGender() {
		tdPage = new TravellerDetailsPage(driver);
		tdPage.checkGenderAndSelectTitleOfAdult();
	}

	@Test(priority = 10)
	public void enteringAdultsDetails() throws InterruptedException {
		tdPage = new TravellerDetailsPage(driver);
		tdPage.enteringTravellerDetails();
	}

	@Test(priority = 11)
	public void fetchingTrvDetails() {
		tbdPage = new TravellerBookedDetailsPage(driver);
		tbdPage.trvDetails();
	}

	@Test(priority = 12)
	public void payment() throws InterruptedException {
		bppPage = new Bus_PaymentPage(driver);
		bppPage.selectingPaymentOptions();
		bppPage.findingClickedPaymentOption();
		// bppPage.debitCardPayment();

	}
}
