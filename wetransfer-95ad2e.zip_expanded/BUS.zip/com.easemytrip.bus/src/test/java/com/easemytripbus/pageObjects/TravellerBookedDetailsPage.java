package com.easemytripbus.pageObjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

public class TravellerBookedDetailsPage {
	WebDriver driver;
	@FindBy(xpath = ("//div[contains(@class,'ps-d mar')]/div"))
	private List<WebElement> travelerDetails;

	public TravellerBookedDetailsPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	public void trvDetails() {
		Reporter.log("Traveller Details Are " + " :");
		for (int t = 0; t < travelerDetails.size(); t++) {
			String trvDetails = travelerDetails.get(t).getAttribute("textContent");
			Reporter.log(trvDetails);
			System.out.println(trvDetails);
		}
	}
}
