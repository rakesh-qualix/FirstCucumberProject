package com.easemytripbus.pageObjects;

import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.easemytripbus.generic.WaitStatementLib;

public class Bus_PaymentPage {
	WebDriver driver;
	// WebElement for Debit Card
	@FindBy(xpath = ("//div[@class='pymnt-bx-lft']/div[@class!='sv-dtl' and @class!='upi']"))
	private List<WebElement> paymentOptionList;
	@FindBy(xpath = ("//div[@id='DivDebitCardPanel']/div[1]/div[2][@class!='clr']"))
	// @FindBy(xpath=("//div[@class='inp-mnu']"))
	private WebElement verifyTextForDebitCreditCard;
	@FindBy(xpath = ("//input[@id='CC']"))
	private WebElement cardNumbrer;
	@FindBy(xpath = ("//input[@id='CCN']"))
	private WebElement cardHolderName;
	@FindBy(xpath = ("//select[@id='CCMM']"))
	private WebElement expMonth;
	@FindBy(xpath = ("//select[@id='CCYYYY']"))
	private WebElement expYear;
	@FindBy(xpath = ("//input[@id='CCCVV']"))
	private WebElement cardCvvNumber;
	@FindBy(xpath = ("//input[@id='CCCVV']"))
	private WebElement cvvNo;
	@FindBy(xpath = ("//div[@class='mk-pym']"))
	private List<WebElement> makePayment;
	/*
	 * WebElement for Net Banking WebElement Icici Internet Banking
	 */
	@FindBy(xpath = ("//div[text()='SELECT POPULAR BANKS']"))
	private WebElement verifyTextForNetBanking;
	@FindBy(xpath = ("//input[@id='rdoICIB'] "))
	private WebElement iciciBank;
	@FindBy(xpath = ("//div[@class='mk-pym3']"))
	private WebElement paymentBtnForNetbanking;
	@FindBy(xpath = ("//input[@name='AuthenticationFG.USER_PRINCIPAL']"))
	private WebElement userId;

	@FindBy(xpath = ("//input[@class='m_loginPass']"))
	private WebElement password;

	@FindBy(xpath = ("//input[@class='login_button']"))
	private WebElement loginBtn;

	public Bus_PaymentPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}

	public boolean isDebitCard(WebElement verifyTextForDebitCreditCard) {

		try {
			WaitStatementLib.iWait(5);
			if (verifyTextForDebitCreditCard.isDisplayed()) {

				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();

		}
		return false;

	}

	public boolean isInternetBanking(WebElement verifyTextForNetBanking) {

		try {
			if (verifyTextForNetBanking.isDisplayed()) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();

		}
		return false;

	}

	public void selectingPaymentOptions() {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e1) {

			e1.printStackTrace();
		}
		Random ra1 = new Random();
		ra1.nextInt(paymentOptionList.size());
		com.easemytripbus.generic.WaitStatementLib.iWait(2);
		// WebElement NameOfPaymentMethod = paymentMode.get(rondomNumber1);
		WebElement NameOfPaymentMethod = paymentOptionList.get(1);
		// WaitStatementLib.iWait(5);
		NameOfPaymentMethod.click();
		com.easemytripbus.generic.WaitStatementLib.iWait(2);
		System.out.println("Selected payment method is : " + NameOfPaymentMethod.getText());
		com.easemytripbus.generic.WaitStatementLib.iWait(2);
	}

	public void debitCardPayment() throws InterruptedException {
		// Thread.sleep(3000);
		cardNumbrer.click();
		cardNumbrer.sendKeys("5546232920724480");
		cardHolderName.click();
		cardHolderName.sendKeys("RAKESH KUMAR JHA");
		Select sel1 = new Select(expMonth);
		sel1.selectByValue("06");
		sel1 = new Select(expYear);
		sel1.selectByValue("2023");
		cvvNo.sendKeys("854");
		makePayment.get(1).click();
		com.easemytripbus.generic.WaitStatementLib.iWait(5);
		driver.findElement(By.xpath("//button[@id='authsubmit']")).click();
		Thread.sleep(5000);

		System.out.println("***************======================****************");
		System.out.println("***************======================****************");

	}

	public void netBankingPayment() throws InterruptedException {
		Thread.sleep(2000);
		iciciBank.click();
		WaitStatementLib.iWait(2);
		paymentBtnForNetbanking.click();
		WaitStatementLib.iWait(2);

		userId.sendKeys("RAKESHJHAJ06");

		password.sendKeys("EASEMYTRIP@2018");

		loginBtn.click();
		WaitStatementLib.iWait(5);
		driver.navigate().back();
		Thread.sleep(1000);
		driver.navigate().back();
		Thread.sleep(10000);
		System.out.println("***************======================****************");
		System.out.println("***************======================****************");

	}

	public void findingClickedPaymentOption() throws InterruptedException {

		if (isDebitCard(verifyTextForDebitCreditCard)) {

			System.out.println("Going to enter Debit card details:");
			debitCardPayment();
		} else if (isInternetBanking(verifyTextForNetBanking)) {
			System.out.println("Going to enter internet banking details:");
			netBankingPayment();
		}
	}
}
