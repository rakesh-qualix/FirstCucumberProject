package com.easemytripbus.pageObjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;

public class TravellerDetailsPage {
	WebDriver driver;
	@FindBy(xpath = ("//select[contains(@class,'sel ng-pristine ng-u')]"))
	private WebElement adultTitle;
	@FindBy(xpath = ("//div[@class='tr-c']/div/div/div[position()>2]/input"))
	private List<WebElement> traveller;
	@FindBy(xpath = ("//span[@class='in ng-binding ng-scope']"))
	private WebElement checkingGender;
	@FindBy(xpath = ("//input[@placeholder='Mobile Number']"))
	private WebElement mobileNo;
	@FindBy(xpath = ("//input[@value='Continue Booking']"))
	private WebElement continueBooking;

	public TravellerDetailsPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}

	public void checkGenderAndSelectTitleOfAdult() {
		String gender = checkingGender.getText();
		String[] gender1 = gender.split("\\(");
		String gen2 = gender1[1];
		String gen3 = gen2.substring(0, gen2.length() - 1);

		try {
			Thread.sleep(1000);
		} catch (InterruptedException e1) {

			e1.printStackTrace();
		}

		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Select sel = new Select(adultTitle);
		if (gen3.equalsIgnoreCase("General")) {
			Reporter.log("Selected Gender is " + " " + "Male");
			sel.selectByIndex(1);
		} else {
			Reporter.log("Selected Gender is " + " " + "Female");
			sel.selectByIndex(2);
		}

	}

	WebElement AdultName;

	public void enteringTravellerDetails() throws InterruptedException {

		for (int t = 0; t < traveller.size(); t++) {
			if (t == 2) {
				traveller.get(t).sendKeys("25");
				break;
			} else
				AdultName = traveller.get(t);

			AdultName.click();
			try {
				if (AdultName != null) {

					AdultName.sendKeys("Test");
				}

			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		mobileNo.sendKeys("9989889958");

		continueBooking.click();
		Thread.sleep(1000);

	}
}
