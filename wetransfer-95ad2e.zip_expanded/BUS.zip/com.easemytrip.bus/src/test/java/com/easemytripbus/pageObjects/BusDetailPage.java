package com.easemytripbus.pageObjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

public class BusDetailPage {
	WebDriver driver;
	@FindBy(xpath = ("//form[@name='myform']/div/div/div/div/div"))
	private List<WebElement> busDetails;
	
	

	public BusDetailPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;

	}
	
	public void findingBusDetails(){
		System.out.println("============================================");
		Reporter.log("Booked Bus Details Are: "+" ");
		System.out.print("Booked Bus Details Are: "+" ");
		for(int b =0;b<8;b++){
			String busDetailsText = busDetails.get(b).getText();
			if(b==8){
				Reporter.log(busDetailsText);
				System.out.println(busDetailsText);
			}else
				Reporter.log(busDetailsText);
			System.out.println(busDetailsText);
		}
		System.out.println("============================================");
	}
	
	
	
}
