package com.easemytripbus.pageObjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

public class Bus_ListingPage {
	WebDriver driver;
	@FindBy(xpath = ("//div[@class='full_wid']/div[2]/div[2]/div[1]/span[@class='ar_cty ng-binding']"))
	private List<WebElement> sectors;
	@FindBy(xpath = ("//a[@id='myBtn']"))
	private List<WebElement> selectSeats;

	public Bus_ListingPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;

	}

	String secName;

	public void selectedSectors() {
		System.out.println("============================================================");
		Reporter.log("Selected Sectors are:" + " ");
		System.out.print("Searched Bus Details:");
		for (int sec = 0; sec < sectors.size(); sec++) {
			secName = sectors.get(sec).getAttribute("textContent");
			Reporter.log(secName);
			System.out.print(secName);
			if (sec == 0) {

				System.out.print("->");
			}
		}

	}

	public void clickOnSelectSeat() throws InterruptedException {
		selectSeats.get(0).click();
		Thread.sleep(5000);

	}

}
