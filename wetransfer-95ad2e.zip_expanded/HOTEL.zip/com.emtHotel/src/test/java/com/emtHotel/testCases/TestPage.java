package com.emtHotel.testCases;

import java.io.File;
import java.io.IOException;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.emtHotel.common.BaseLib;
import com.emtHotel.objects.HotelGuestDetailsPage;
import com.emtHotel.objects.HotelHomePage;
import com.emtHotel.objects.HotelListingPage;
import com.emtHotel.objects.HotelPaymentPage;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class TestPage extends BaseLib {
	ExtentReports extent;
	ExtentTest logger;
	HotelHomePage hhp;
	HotelListingPage hlp;
	HotelGuestDetailsPage hgdp;
	HotelPaymentPage hpp;

	@BeforeTest
	public void startReport() {

		// extent = new ExtentReports(System.getProperty("user.dir") +
		// "/test-output/html/FlightExtentReport.html", true);
		extent = new ExtentReports(
				System.getProperty("user.dir") + "test-output\\ExtentReport\\FlightExtentReport.html", true);
		// extent = new ExtentReports(System.getProperty("user.dir") +
		// "FlightxtEntReport.html", true);

		extent.addSystemInfo("Host Name", "RAKESH KUMAR JHA").addSystemInfo("Environment", "QA Server")
				.addSystemInfo("User Name", "EASY TRIP PLANNERS PVT LTD.");
		extent.loadConfig(new File(System.getProperty("user.dir") + "\\extent-config.xml"));
	}

	@Test(priority = 1)
	public void searchHotel() throws InterruptedException {
		logger = extent.startTest("searchHotel");
		Assert.assertTrue(true);
		hhp = new HotelHomePage(driver);
		hhp.hotelCity();
		hhp.check_InDate();
		hhp.check_OutDate();
		hhp.search();
	}

	@Test(priority = 2, dependsOnMethods = "searchHotel")
	public void listingHotel() {
		logger = extent.startTest("listingHotel");
		Assert.assertTrue(true);
		hlp = new HotelListingPage(driver);
		hlp.hotelListing();
		try {
			Thread.sleep(1000);
			hlp.bookingDetails();
			hlp.bookNow();

		} catch (InterruptedException e) {

			e.printStackTrace();
		}

	}

	@Test(priority = 3, dependsOnMethods = "listingHotel")
	public void enteringGuestDetails() {
		logger = extent.startTest("enteringGuestDetails");
		Assert.assertTrue(true);
		hgdp = new HotelGuestDetailsPage(driver);
		// hgdp.hotelDetails();
		hgdp.guestDetails();
		hgdp.guestContact();
		hgdp.fareDetails();
	}

	@Test(priority = 4, dependsOnMethods = "enteringGuestDetails")
	public void hotelPayment() throws InterruptedException {
		logger = extent.startTest("hotelPayment");
		Assert.assertTrue(true);
		hpp = new HotelPaymentPage(driver);
		hpp.selectingPaymentOptions();
		hpp.findingClickedPaymentOption();
		// hpp.debitCardPayment();
		// hpp.netBankingPayment();

	}

	@AfterMethod
	public void getResult(ITestResult result) throws IOException {
		if (result.getStatus() == ITestResult.FAILURE) {

			logger.log(LogStatus.FAIL, result.getMethod().getMethodName() + "Test Case Failed");
			logger.log(LogStatus.FAIL, "Test Case Failed Exception is " + result.getThrowable());
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}

			/*
			 * logger.log(LogStatus.FAIL, logger.addScreenCapture(
			 * "D:\\EasemytripFlightProject\\com.emtFlightLive\\ScreenShot" +
			 * result.getMethod().getMethodName() + ".png"));
			 */
			logger.log(LogStatus.FAIL,
					logger.addScreenCapture("D:\\EasemytripFlightProject\\com.emtHotel\\screenshots\\"
							+ result.getMethod().getMethodName() + ".png"));
			/*
			 * logger.log(LogStatus.FAIL, logger.addScreenCapture(
			 * "http://localhost:8080\\job\\EaseMyTrip Flight\\com.easytripplanners.easemytrip$easemytripFlight\\ws\\screenshots\\"
			 * + result.getMethod().getMethodName() + ".png"));
			 */

		} else if (result.getStatus() == ITestResult.SUCCESS) {
			logger.log(LogStatus.PASS, result.getName() + "  " + "Test Case Passed");
		}

		else if (result.getStatus() == ITestResult.SKIP) {
			logger.log(LogStatus.SKIP, "Test Case Skipped is " + result.getName());
		}

		extent.endTest(logger);

	}

	@AfterTest
	public void endReport() {

		// flush() - to write or update test information to your report.
		extent.flush();

		extent.close();

	}

}
