package com.emtHotel.objects;

public class HotelReviewPage {

}
