package com.emtHotel.objects;

import java.util.List;
import java.util.Random;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Test;
import com.emtHotel.common.WaitStatementLib;

public class HotelPaymentPage {
	WebDriver driver;
	// @FindBy(xpath = ("//div[@class='pymnt-bx-lft']/div[@class!='sv-dtl' and
	// @class!='bharatqr']"))
//	@FindBy(xpath = ("//div[@class='pymnt-bx-lft']/div[@class!='sv-dtl'  and @class!='bharatqr'][position()>1]"))
	//UPI and Bharat QR Payment is not included in this xpath
	@FindBy(xpath = ("//div[@class='pymnt-bx-lft']/div[@class!='sv-dtl'and @class!='bharatqr' and @class!='upi' and @class!='pay_pal'][position()>1]"))
	private List<WebElement> paymentMode;
	// ========================================================================================

	// Storing elements for Debit and credit cards
	@FindBy(xpath = ("//div[text()='ENTER YOUR CARD NO.']"))
	private WebElement verifyTextForDebitCreditCard;
	@FindBy(xpath = ("//input[@id='CC']"))
	private WebElement cardNumbrer;
	@FindBy(xpath = ("//input[@id='CCN']"))
	private WebElement cardHolderName;
	@FindBy(xpath = ("//input[@id='CCMM']"))
	private WebElement expMonth;
	@FindBy(xpath = ("//input[@id='CCYYYY']"))
	private WebElement expYear;
	@FindBy(xpath = ("//input[@id='CCCVV']"))
	private WebElement cardCvvNumber;
	@FindBy(xpath = ("//div[@class='pymnt-bx-rgt']/div[7]/div[2]"))
	private WebElement makePaymentForDCCard;
	// ========================================================================================

	// ========================================================================================
	// Storing WebElement and List<WebElement> for NetBanking
	@FindBy(xpath = ("//div[@class='pymnt-bx-rgt3']/div[1]/div[2]"))
	private WebElement verifyTextForNetbanking;
	@FindBy(xpath = ("//select[@id='drpBank']"))
	private WebElement bankDrpDwn;
	@FindBy(xpath = ("//div[@class='mk-pym3']"))
	private WebElement paymentBtnForNetbanking;
	// Icici Internet Banking Details
	@FindBy(xpath = ("//input[@id='AuthenticationFG.LOGIN_MOBILE']"))
	private WebElement mobileForLogin;
	@FindBy(xpath = ("//input[@id='VALIDATE_MOBILE_LOGIN']"))
	private WebElement loginBtn;
	// ========================================================================================

	// ========================================================================================
	// Storing WebElements for MyWallet
	@FindBy(xpath = ("//div[text()='SELECT POPULAR Wallets']"))
	private WebElement verifyTextForMyWallet;
	@FindBy(xpath = ("//div[@class='radi-bt4']/div[@class!='clr']/div[1]"))
	private List<WebElement> myWallet;
	@FindBy(xpath = ("//div[@class='main-pymnt-bx']/div[5]/div[3]/div[2]"))
	private WebElement walletMakePayment;
	// WebElements for MobiKwik Money Wallet
	@FindBy(xpath = ("//div[@id='signinlyr']/h2"))
	private WebElement mobikwikText;
	@FindBy(xpath = ("//input[@id='logininput']"))
	private WebElement mobikwikMobile;
	@FindBy(xpath = ("//input[@id='pwdsignininput']"))
	private WebElement mobikwikPassword;
	@FindBy(xpath = ("//input[@id='signinFrm']"))
	private WebElement mobikwikSubmitBtn;
	@FindBy(xpath = ("//a[@id='DC']"))
	private WebElement debitCreditCard;
	@FindBy(xpath = ("//input[@id='cc_number']"))
	private WebElement cardNo;
	@FindBy(xpath = ("//select[@id='cc_exp_month']"))
	private WebElement cardMonth;
	@FindBy(xpath = ("//select[@id='cc_exp_year']"))
	private WebElement cardYear;
	@FindBy(xpath = "//input[@id='cc_cvv']")
	private WebElement cardCvv;
	@FindBy(xpath = ("//input[@id='paymentdivbutton']"))
	private WebElement payNowBtn;
	@FindBy(xpath = "//button[@id='authsubmit']")
	private WebElement continueToFailTransaction;
	@FindBy(xpath = ("//input[@id='back']"))
	private WebElement backToMerchantSideBtn;
	// ========================================================================================

	// ========================================================================================
	// Element for PhonePayVerificationText under Wallet

	@FindBy(xpath = ("//input[@id='mobileNumber']"))
	private WebElement mobileNumberForPhonePay;
	@FindBy(xpath = ("//button[@id='onboardingFormSubmitBtn']"))
	private WebElement sendBtn;
	@FindBy(xpath = ("//div[@class='main-pymnt-bx']/div[6]/div[3]/div[2]"))
	private WebElement makePaymentForverifyTextForPhonePayOpt;
	@FindBy(xpath = ("//div[@id='ms-header-content']/div/h1"))
	private WebElement verifyPhonePayTextUnderWallet;
	@FindBy(xpath = ("//input[@name='mobileNumber']"))
	private WebElement mobileNo;
	@FindBy(xpath = ("//button[@id='onboardingFormSubmitBtn']"))
	private WebElement phonePaySendBtn;
	// ========================================================================================

	// ========================================================================================
	// WebElements for Airtel Money Wallet
	@FindBy(xpath = ("//div[@class='login-panel']/h2"))
	private WebElement verifyTextForAirtelWallet;
	@FindBy(xpath = ("//input[@id='usernameInput']"))
	private WebElement MobileNumber;
	@FindBy(xpath = ("//a[text()='LOGIN WITH OTP']"))
	private WebElement loginWithOTP;
	@FindBy(xpath = ("//button[@class='cross-right']"))
	private WebElement crossSign;
	@FindBy(xpath = ("//a[text()='Cancel']"))
	private WebElement cancelTransaction;
	// ========================================================================================

	// ========================================================================================
	// Storing WebElement for AmazonPay Wallet
	@FindBy(xpath = ("//div[@id='authportal-main-section']/div[2]/div/div/form/div/div/div/h1"))
	private WebElement verifyTextForAmazonPayWallet;
	@FindBy(xpath = ("//input[@id='ap_email']"))
	private WebElement emailOrMobilePhoneNumber;
	@FindBy(xpath = ("//input[@id='ap_password']"))
	private WebElement amazonAppPassword;
	@FindBy(xpath = ("//input[@id='signInSubmit']"))
	private WebElement amazonAppLoginBtn;
	@FindBy(xpath = ("//div[@id='net-banking']/div/div/a/i"))
	private WebElement radioBtnForNetBanking;
	@FindBy(xpath = ("//span[@id='nb-option']"))
	private WebElement chooseBankForNetBanking;
	@FindBy(xpath = ("//div[@class='a-popover-inner a-lgtbox-vertical-scroll']/ul/li"))
	private List<WebElement> bankList;
	@FindBy(xpath = ("//div[@id='pay-btn-popover']"))
	private WebElement payNowBtnForAmazonApp;
	@FindBy(xpath = ("//input[@id='CANCEL_SHOPPING_MALL_PMT']"))
	private WebElement IciciBankTransactionCancelBtn;
	// ========================================================================================

	// ========================================================================================
	// Storing WebElement for ePayLater Wallet
	@FindBy(xpath = ("//div[@class='right_inner']/p"))
	private WebElement verifyTextForSignInForEPayLater;
	@FindBy(xpath = ("//div[@class='form-group select_enter mobile_error']"))
	private WebElement ePayLaterMobile;
	@FindBy(xpath = ("//input[@id='continueButton']"))
	private WebElement ePayLaterContinueBtn;
	@FindBy(xpath = ("//a[@id='cancelButton']"))
	private WebElement ePayLaterCancelBtn;
	// ========================================================================================

	// ========================================================================================
	// Storing WebElement for EMI
	@FindBy(xpath = ("//div[text()='SELECT  BANKS']"))
	private WebElement verifyTextForEmi;
	@FindBy(xpath = ("//select[@id='drpEMIBank']/option"))
	private List<WebElement> emiBankOptions;
	@FindBy(xpath = ("//input[@id='emi_opt_1']"))
	private WebElement emiPlan;
	@FindBy(xpath = ("//input[@id='CC1']"))
	private WebElement creditCardNo;
	@FindBy(xpath = ("//input[@id='CCN1']"))
	private WebElement creditCardHolderName;
	@FindBy(xpath = ("//select[@id='CCMM1']"))
	private WebElement creditCardExpiryMonth;
	@FindBy(xpath = ("//select[@id='CCYYYY1']"))
	private WebElement creditCardExpiryYear;
	@FindBy(xpath = ("//input[@id='CCCVV1']"))
	private WebElement credirCardCvvNo;
	@FindBy(xpath = ("//div[@class='mk-pym']"))
	private List<WebElement> creditCardMakePayment;
	// ========================================================================================
	
	// ========================================================================================
	
	// ========================================================================================
	
	//Storing WebElement for Google Pay
	@FindBy(xpath=("//span[contains(text(),'Enter the phone no.')]"))
	private WebElement verifyTextForGooglePay;
	@FindBy(xpath=("//input[@id='txtGooglePhone']"))
	private WebElement googlePayMobileNo;
	@FindBy(xpath=("//div[@class='gpay-btn']"))
	private WebElement googlePayVerifyAndPayBtn;
	
	
	// ========================================================================================
	
	/*// Storing WebElement for Paypal Payment option
		@FindBy(xpath = ("//div[@class='paypal_btn']"))
		private WebElement paypalBtn;
		@FindBy(xpath = ("//div[@class='pym']"))
		private WebElement verifyCurrency;
		@FindBy(xpath = ("//a[@class='btn full ng-binding']"))
		private WebElement payPalLogInBtn;
		@FindBy(xpath = ("//input[@id='email']"))
		private WebElement payPalEmailAddress;
		@FindBy(xpath = ("//input[@id='password']"))
		private WebElement payPalPassword;
		@FindBy(xpath = ("//button[@id='btnLogin']"))
		private WebElement payPalLogInBtn1;
		//@FindBy(xpath = ("//span[text()='Cancel and return to EASY TRIP PLANNERS PRIVATE LIMITED']"))
		@FindBy(xpath = ("//a[@id='cancelLink']"))
		private WebElement payPalCancelLink;
		// ========================================================================================
*/		
	public HotelPaymentPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}// for initialization of WebElement

	@Test
	public void selectingPaymentOptions() throws InterruptedException {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e1) {

			e1.printStackTrace();
		}
		 Random ra1 = new Random();
		 int rondomNumber1 = ra1.nextInt(paymentMode.size());
		// WebElement NameOfPaymentMethod = paymentMode.get(rondomNumber1);
		WebElement NameOfPaymentMethod = paymentMode.get(2);
		Thread.sleep(2000);
		NameOfPaymentMethod.click();
		Reporter.log("Selected payment method is : " + NameOfPaymentMethod.getText());
		System.out.println("Selected payment method is : " + NameOfPaymentMethod.getText());

	}

	@Test
	public void debitCardPayment() throws InterruptedException {
		//Reporter.log("Selected payment method is Debit/Credit card!!!");
		cardNumbrer.click();
		cardNumbrer.sendKeys("5546232920724480");
		cardHolderName.click();
		cardHolderName.sendKeys("RAKESH KUMAR JHA");
		expMonth.sendKeys("06");
		expYear.sendKeys("2023");
		cardCvvNumber.sendKeys("854");
		makePaymentForDCCard.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@id='authsubmit']")).click();
		Thread.sleep(5000);
		System.out.println("***************======================****************");
		System.out.println("***************======================****************");

	}

	public void netBankingPayment() throws InterruptedException {
		//Reporter.log("Selected payment method is Internet Banking!!!");
		Thread.sleep(2000);
		bankDrpDwn.click();
		Select sel = new Select(bankDrpDwn);
		sel.selectByIndex(1);
		paymentBtnForNetbanking.click();
		Thread.sleep(2000);
		mobileForLogin.sendKeys("9971997901");
		Thread.sleep(2000);
		loginBtn.click();
		Thread.sleep(2000);
		driver.navigate().back();
		Thread.sleep(1000);
		driver.navigate().back();
		Thread.sleep(1000);
		System.out.println("***************======================****************");
		System.out.println("***************======================****************");

	}

	public void phonePayOptionPayment() throws InterruptedException {
		// Enable code for saved card only
		makePaymentForverifyTextForPhonePayOpt.click();
		Thread.sleep(2000);
		mobileNumberForPhonePay.click();
		WaitStatementLib.iWait(2);
		// mobileNumberForPhonePay.clear();
		mobileNumberForPhonePay.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));
		WaitStatementLib.iWait(2);
		// Assert.fail("Not able to clear!!!");
		mobileNumberForPhonePay.sendKeys("9971997901");
		// WaitStatementLib.iWait(5);
		WaitStatementLib.iWait(2);
		mobileNumberForPhonePay.sendKeys("9971997901");
		WaitStatementLib.iWait(2);
		sendBtn.click();
		WaitStatementLib.iWait(2);
		System.err.println("Cancel transaction without entering OTP!!!");
		System.out.println("===========================================");
	}

	public boolean isMobikwik(WebElement mobikwikText) {
		try {
			if (mobikwikText.isDisplayed()) {
				return true;
			}
		} catch (Exception e) {

		}
		return false;
	}

	public boolean isPhonePay(WebElement verifyPhonePayTextUnderWallet) {
		try {
			if (verifyPhonePayTextUnderWallet.isDisplayed()) {
				return true;

			}
		} catch (Exception e) {

		}
		return false;
	}

	public boolean isAirtel(WebElement verifyTextForAirtelWallet) {
		try {
			if (verifyTextForAirtelWallet.isDisplayed()) {
				return true;
			}
		} catch (Exception e) {

		}
		return false;
	}

	public boolean isAmazonPay(WebElement verifyTextForAmazonPayWallet) {
		try {
			if (verifyTextForAmazonPayWallet.isDisplayed()) {
				return true;
			}
		} catch (Exception e) {

		}
		return false;
	}

	public boolean isePayLater(WebElement verifyTextForSignInForEPayLater) {
		try {
			if (verifyTextForSignInForEPayLater.isDisplayed()) {
				return true;
			}
		} catch (Exception e) {

		}
		return false;
	}

	public void walletPayment() {
		try {
			WaitStatementLib.iWait(1);
			Random Wallet = new Random();
			int rondomWallet = Wallet.nextInt(myWallet.size());
			//WebElement walletPaymentMethod = myWallet.get(rondomWallet);
			 WebElement walletPaymentMethod = myWallet.get(2);
			//Thread.sleep(2000);
			walletPaymentMethod.click();
			//WaitStatementLib.iWait(2);
			walletMakePayment.click();
			//Thread.sleep(3000);
			paymentDoneByWallet();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void paymentDoneByWallet() {
		if (isMobikwik(mobikwikText)) {

			mobikwikWalletPayment();
		} 
		else if (isAmazonPay(verifyTextForAmazonPayWallet)) {
			amazonPayWalletPayment();
		}else if (isPhonePay(verifyPhonePayTextUnderWallet)) {
			phonePayWalletpayment();
		} else if (isAirtel(verifyTextForAirtelWallet)) {
			airtelWalletPayment();
		} 
		 else if (isePayLater(verifyTextForSignInForEPayLater)) {
			ePayLaterWalletPayment();
		}

	}

	public void mobikwikWalletPayment() {
		try {
			System.out.println("Selected Wallet is Mobikwik");
			Thread.sleep(1000);
			mobikwikMobile.click();
			Thread.sleep(1000);
			mobikwikMobile.clear();
			Thread.sleep(1000);
			mobikwikMobile.sendKeys("7827792395");
			Thread.sleep(1000);
			mobikwikPassword.click();
			Thread.sleep(1000);
			mobikwikPassword.sendKeys("anjali24");
			Thread.sleep(1000);
			mobikwikSubmitBtn.click();
			Thread.sleep(2000);
			debitCreditCard.click();
			Thread.sleep(2000);
			cardNo.click();
			Thread.sleep(1000);
			cardNo.sendKeys("5546232920724480");
			Thread.sleep(1000);
			Select selMobikwik = new Select(cardMonth);
			selMobikwik.selectByVisibleText("06");
			selMobikwik = new Select(cardYear);
			selMobikwik.selectByValue("2023");
			cardCvv.sendKeys("854");
			Thread.sleep(2000);
			payNowBtn.click();
			Thread.sleep(6000);
			System.out.println("***************======================****************");
			System.out.println("***************======================****************");
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	public void phonePayWalletpayment() {
		try {
			Reporter.log("Selected Wallet is PhonePay Wallet!!!");
			System.out.println("Selected Wallet is PhonePay");
			mobileNo.click();
			try {
				mobileNo.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));

			} catch (Exception e) {
				e.printStackTrace();
			}
			mobileNo.sendKeys("9971997901");
			phonePaySendBtn.click();
			System.err.println("Cancel transaction without entering OTP!!!");
			System.out.println("===========================================");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void airtelWalletPayment() {
		try {
			Reporter.log("Selected Wallet is Airtel Wallet!!!");
			MobileNumber.click();
			WaitStatementLib.iWait(2);
			MobileNumber.clear();
			WaitStatementLib.iWait(2);
			MobileNumber.sendKeys("9971997901");
			WaitStatementLib.iWait(2);
			loginWithOTP.click();
			WaitStatementLib.iWait(10);
			crossSign.click();
			Thread.sleep(5000);
			System.out.println("***************======================****************");
			System.out.println("***************======================****************");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void ePayLaterWalletPayment() {
		try {
			Reporter.log("Selected Wallet is ePayLater!!!");
			ePayLaterCancelBtn.click();
			Thread.sleep(1000);
			System.out.println("***************======================****************");
			System.out.println("***************======================****************");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void amazonPayWalletPayment() {
		try {
			Reporter.log("Selected Wallet is AmazonPay!!!");
			emailOrMobilePhoneNumber.click();
			emailOrMobilePhoneNumber.sendKeys("rakeshit0913@gmail.com");
			amazonAppPassword.click();
			amazonAppPassword.sendKeys("9971997901");
			amazonAppLoginBtn.click();
			Thread.sleep(1000);
			//Need to work tomorrow
			radioBtnForNetBanking.click();
			Thread.sleep(1000);
			chooseBankForNetBanking.click();
			bankList.get(2).click();
			Thread.sleep(2000);
			payNowBtnForAmazonApp.click();
			Thread.sleep(2000);
			mobileForLogin.sendKeys("9971997901");
			System.out.println("***************======================****************");
			System.out.println("***************======================****************");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void emiPayment() throws InterruptedException {
		//Reporter.log("Selected payment method is EMI!!!");
		WebElement bankName = emiBankOptions.get(2);
		bankName.click();
		WaitStatementLib.iWait(3);
		emiPlan.click();
		WaitStatementLib.iWait(2);
		creditCardNo.click();
		creditCardNo.sendKeys("4375514558134002");
		creditCardHolderName.click();
		creditCardHolderName.sendKeys("Rakesh Kumar Jha");
		Select sel2 = new Select(creditCardExpiryMonth);
		sel2.selectByVisibleText("09");
		sel2 = new Select(creditCardExpiryYear);
		sel2.selectByVisibleText("2020");
		credirCardCvvNo.click();
		credirCardCvvNo.sendKeys("144");
		WaitStatementLib.iWait(2);
		creditCardMakePayment.get(1).click();
		WaitStatementLib.iWait(5);
		driver.navigate().back();
		Thread.sleep(5000);
		System.out.println("***************======================****************");
		System.out.println("***************======================****************");

	}
	public  void googlePayPayment(){
		googlePayMobileNo.click();                                              
		try {
			Thread.sleep(1000);
			googlePayMobileNo.sendKeys("9971997901");
			Thread.sleep(1000);
			googlePayVerifyAndPayBtn.click();
			Thread.sleep(20000);
			driver.switchTo().alert().accept();
			System.err.println("OOPs!!! Transaction was declined by Google Pay User...");
		} catch (InterruptedException e) {
		
			e.printStackTrace();
		}
	}
	/*public void payPalPayment() throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, 20);
		WebElement payWithPaypal = wait
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='mk-pyz']")));
		payWithPaypal.click();
		Thread.sleep(8000);
		WebDriverWait wait1 = new WebDriverWait(driver, 20);
		WebElement logInToPayPal = wait1
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@class='btn full ng-binding']")));
		Thread.sleep(5000);
		logInToPayPal.click();

		Thread.sleep(5000);
		payPalEmailAddress.clear();
		payPalEmailAddress.sendKeys("kumar.rakeshjha7901@gmail.com");
		payPalPassword.sendKeys("rakeshjha1990");
		//payPalLogInBtn1.click();
		//Thread.sleep(5000);
		WebDriverWait waitP = new WebDriverWait(driver, 2);
		Thread.sleep(1000);
		waitP.until(ExpectedConditions.elementToBeClickable(payPalCancelLink)).click();
		
		// payPalCancelLink.click();
		Thread.sleep(10000);
		
	}*/

	public boolean isDebitCard(WebElement verifyTextForDebitCreditCard) {
		try {
			WaitStatementLib.iWait(2);
			if (verifyTextForDebitCreditCard.isDisplayed()) {

				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();

		}
		return false;

	}

	public boolean isInternetBanking(WebElement verifyTextForNetBanking) {

		try {
			if (verifyTextForNetBanking.isDisplayed()) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();

		}
		return false;

	}

	public boolean isWallet(WebElement verifyTextForMyWallet) {
		try {
			if (verifyTextForMyWallet.isDisplayed()) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();

		}
		return false;

	}

	public boolean isUpi(WebElement verifyTextForUPI) {
		try {
			if (verifyTextForUPI.isDisplayed()) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();

		}
		return false;

	}

	public boolean isEmi(WebElement verifyTextForEmi) {
		try {
			if (verifyTextForEmi.isDisplayed()) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;

	}
	public boolean isGooglePayPayment(WebElement verifyTextForGooglePay){
		try{
			if(verifyTextForGooglePay.isDisplayed()){
				return true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return false;
		
	}

	/*public boolean isPayPalPayment(WebElement verifyCurrency) {
		try {
			if (verifyCurrency.isDisplayed()) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;

	}*/

	public void findingClickedPaymentOption() throws InterruptedException {
		if (isDebitCard(verifyTextForDebitCreditCard)) {
			System.out.println("Going to enter Debit card details:");
			debitCardPayment();
		} else if (isInternetBanking(verifyTextForNetbanking)) {
			System.out.println("Going to enter internet banking details:");
			netBankingPayment();
			// need to add emi script here tomorrow
		} else if (isWallet(verifyTextForMyWallet)) {
			System.out.println("Going to enter Wallet details:");
			walletPayment();
		} else if (isEmi(verifyTextForEmi)) {
			System.out.println("Going to enter Wallet details:");
			emiPayment();
		}
		else if(isGooglePayPayment(verifyTextForGooglePay)){
			System.out.println("Going to make payment through Google Pay!!!");
			 googlePayPayment();
		}
		//Remove comment for Paypal Payment
		/*else if (isPayPalPayment(verifyCurrency)) {
			System.out.println("Going to make Payment through Paypal");
			payPalPayment();
		}*/ 

		else {
			System.out.println("Going to enter verifyTextForPhonePay details:");
			phonePayOptionPayment();
		}

	}
}
