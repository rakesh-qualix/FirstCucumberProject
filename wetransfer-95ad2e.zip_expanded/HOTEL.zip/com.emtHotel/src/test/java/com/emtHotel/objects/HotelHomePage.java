package com.emtHotel.objects;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class HotelHomePage {
	WebDriver driver;
	@FindBy(xpath = ("//input[@id='txtCity']"))
	private WebElement hotelCity;
	@FindBy(xpath = ("//input[@id='txtCheckInDate']"))
	private WebElement check_In;
	@FindBy(xpath = ("//span[text()='Check-out']"))
	private WebElement check_Out;
	@FindBy(xpath = ("//input[@id='guestcount']"))
	private WebElement guestCount;
	@FindBy(xpath = ("//input[@id='btnDiv']"))
	private WebElement searchBtn;

	public HotelHomePage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}

	@Test

	public void hotelCity() throws InterruptedException {
		List<String> hotelCitiesList = Arrays.asList("Bengaluru", "Mumbai", "Chennai", "Hyderabad", "Kolkata", "Pune",
				"Ahmedabad", "Jaipur", "Surat", "New Delhi", "Chandigarh", "Kochi", "Noida", "Gurugram", "Indore",
				"Agra", "Bhopal", "Udaipur", "Nagpur", "Patna", "Vadodara", "Mysore", "Bhubaneshwar", "Varanasi",
				"Coimbatore", "Raipur", "Kanpur", "Shimla", "Goa");
		Random random = new Random();
		int randomHotel = random.nextInt(hotelCitiesList.size());
		String searchedHotelCity = hotelCitiesList.get(randomHotel);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		// use executeScript() method and pass the arguments
		// Here i pass values based on css style. Yellow background color with
		// solid red color border.
		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');",
				hotelCity);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e1) {

			e1.printStackTrace();
		}
		hotelCity.click();
		Thread.sleep(2000);
		hotelCity.sendKeys(searchedHotelCity);

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		hotelCity.sendKeys(Keys.ENTER);
		Reporter.log("Searching hotel for" + " " + searchedHotelCity);

	}

	@Test(dependsOnMethods = "hotelCity")
	public void check_InDate() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		// use executeScript() method and pass the arguments
		// Here i pass values based on css style. Yellow background color with
		// solid red color border.
		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", check_In);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e1) {

			e1.printStackTrace();
		}
		check_In.click();
		List<WebElement> chkInDate = driver.findElements(By.xpath(
				"//div[@class='ui-datepicker-group ui-datepicker-group-first']/table/tbody/tr/td[@data-handler='selectDay']"));
		int sizeOfActiveChkDate = chkInDate.size();
		Random chkIn = new Random();
		int randomChkInDate = chkIn.nextInt(sizeOfActiveChkDate);
		WebElement selectedCheckInDate = chkInDate.get(randomChkInDate);

		selectedCheckInDate.click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}

	}

	@Test(dependsOnMethods = "check_InDate")
	public void check_OutDate() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		// use executeScript() method and pass the arguments
		// Here i pass values based on css style. Yellow background color with
		// solid red color border.
		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');",
				check_Out);
		check_Out.click();
		List<WebElement> chkOutDate = driver.findElements(By.xpath(
				"//div[@class='ui-datepicker-group ui-datepicker-group-first']/table/tbody/tr/td[@data-handler='selectDay']"));
		int sizeOfActiveChkDate = chkOutDate.size();
		Random chkIn = new Random();
		int randomChkOutDate = chkIn.nextInt(sizeOfActiveChkDate);
		WebElement selectedCheckOutDate = chkOutDate.get(randomChkOutDate);

		selectedCheckOutDate.click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}

	}

	@Test(dependsOnMethods = "check_OutDate")
	public void search() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		// use executeScript() method and pass the arguments
		// Here i pass values based on css style. Yellow background color with
		// solid red color border.
		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');",
				searchBtn);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e1) {

			e1.printStackTrace();
		}
		searchBtn.click();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		System.err.println("Wait We are searching best hotel for You!!!");
	}

}
