package com.airlines.pageObject;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class FlyDubaiSrcAndDest {

	public WebDriver driver;
	String xmlStr1;
	String xmlStr = "<Table>\n" + "  <Origin>#origin#</Origin>\n" + "<Destination>#destination#</Destination>\n"
			+ "    <EngineID>FlyDubai</EngineID>\n" + "  </Table>";
	WebElement flyingFrom;
	String s = "";
	String ele;

	String c = "";
	String arr;
	String finalSource;

	@BeforeTest
	public void launchWebsite() {
		driver = new FirefoxDriver();

		driver.get("https://www.flydubai.com/en/destinations/airports/");
		driver.manage().window().maximize();
		System.out.println("Sucessfully opened the website https://www.flydubai.com/en/");

	}

	@Test
	public void flyingFrom() throws InterruptedException {
		/*
		 * flyingFrom = driver.findElement( By.xpath(
		 * "//form[@name='make-a-booking-form-desktop']/div/div[1]/div/span/span[1]/input[1]"
		 * )); flyingFrom.click();
		 */

		List<String> listOfAirportSourceCode = Arrays.asList("AHB", "ADD", "AMD", "DWC", "HBE", "ALA", "AMM", "ASB",
				"ASM", "TSE", "IXU", "IXB", "BGW", "BAH", "GYD", "BKK", "BSR", "BUS", "BEY", "BEG", "BLR", "BHU", "BHJ",
				"FRU", "KBP", "BTS", "OTP", "CTA", "IXC", "MAA", "CJB", "CMB", "DMM", "DAR", "DED", "DEL", "IDR", "DAC",
				"JIB", "NAG", "DYU", "EBB", "EBL", "IFN", "LYP", "ZAG", "ELQ", "GIZ", "GOI", "CAN", "HAS", "HGA", "HEL",
				"HYD", "IMF", "SAW", "JAI", "IXJ", "JED", "JDH", "JRH", "JUB", "KBL", "KHI", "KTM", "KZN", "HJR", "KRT",
				"JRO", "FIH", "COK", "KRK", "KRR", "KWI", "VNS", "LRR", "IXL", "AJL", "PAT", "GAU", "LKO", "MED", "IXM",
				"UDR", "MCX", "MLE", "IXE", "MHD", "MRV", "MSQ", "MUX", "BOM", "MCT", "NJF", "NRT", "CCU", "ODS", "JNB",
				"PZU", "PRG", "PNQ", "GBB", "UET", "RPR", "BHO", "RJA", "RAJ", "RUH", "ROV", "SLL", "KUF", "SJJ", "SXR",
				"SVO", "SYZ", "CIT", "SKT", "IXS", "SKP", "CGK", "SOF", "ATQ", "ISU", "TUU", "TIF", "TBS", "SKG", "TRV",
				"TRZ", "TIV", "UFA", "BDQ", "IXZ", "VTZ", "VKO", "SVX", "EVN", "ZNZ", "IEV", "DXB", "MOW");

		int sizeofFlyintTo = listOfAirportSourceCode.size();
		System.out.println(sizeofFlyintTo);
		for (int i = 0; i < sizeofFlyintTo; i++) {
			ele = listOfAirportSourceCode.get(i);
			if (i >= 0) {
				s = "";
				flyingFrom = driver.findElement(
						By.xpath("//form[@name='make-a-booking-form-desktop']/div/div[1]/div/span/span[1]/input[1]"));
				flyingFrom.click();
				// Thread.sleep(1000);
				flyingFrom.clear();
			}
			if (Stream.of("ALA", "AMM", "BAH", "BUS", "BHU", "DAR", "HAS", "PAT", "LKO", "DXB")
					.anyMatch(ele::equalsIgnoreCase)) {
				flyingFrom.sendKeys(ele);
				// Thread.sleep(1000);
				flyingFrom.sendKeys(Keys.ENTER);
				flyingTo();
			} else if (Stream.of("NAG", "HGA", "MED", "ROV", "IEV").anyMatch(ele::equalsIgnoreCase)) {
				flyingFrom.sendKeys(ele);
				// Thread.sleep(1000);
				flyingFrom.sendKeys(Keys.ARROW_DOWN);
				// Thread.sleep(1000);
				flyingFrom.sendKeys(Keys.ENTER);
				flyingTo();
			} else if (Stream.of("RAJ").anyMatch(ele::equalsIgnoreCase)) {
				flyingFrom.sendKeys(ele);
				Thread.sleep(2000);
				flyingFrom.sendKeys(Keys.ARROW_DOWN);
				Thread.sleep(1000);
				flyingFrom.sendKeys(Keys.ARROW_DOWN);
				Thread.sleep(1000);
				flyingFrom.sendKeys(Keys.ENTER);
				Thread.sleep(1000);
				flyingTo();
			} else {
				flyingFrom.sendKeys(ele);
				// Thread.sleep(1000);
				flyingTo();
			}
		}

		/*
		 * driver.findElement(By.xpath("//select[@id='city']")).click(); String
		 * cityList = "//select[@id='city']/option[position()>1]";
		 * List<WebElement> citiesName =
		 * driver.findElements(By.xpath(cityList)); int sizeOfCities =
		 * citiesName.size();
		 * 
		 * List<String> listOfSource = new ArrayList<String>(); for (int i = 0;
		 * i < sizeOfCities; i++) { WebElement textOfCity = citiesName.get(i);
		 * String nameOfCity = textOfCity.getAttribute("textContent");
		 * System.out.println(nameOfCity); listOfSource.add(nameOfCity); } for
		 * (int j = 0; j < listOfSource.size(); j++) { if (j >= 0) { s="";
		 * flyingFrom = driver.findElement( By.xpath(
		 * "//form[@name='make-a-booking-form-desktop']/div/div[1]/div/span/span[1]/input[1]"
		 * )); flyingFrom.click(); Thread.sleep(1000); flyingFrom.clear(); }
		 * flyCity = listOfSource.get(j);
		 * 
		 * flyingFrom.sendKeys(flyCity);
		 * 
		 * flyingTo(); }
		 */

	}

	@Test
	public void flyingTo() throws InterruptedException {
		WebElement flyingTo = driver.findElement(
				By.xpath("//form[@name='make-a-booking-form-desktop']/div/div[1]/div/span/span[3]/input[1]"));
		flyingTo.click();
		// Thread.sleep(1000);
		flyingTo.clear();
		Thread.sleep(2000);
		String flyingToList = "//form[@id='frmSearch']/div/div[1]/div/span/span[3]/div/ul/li/span[1]";
		// Thread.sleep(1000);
		List<WebElement> flyingToCities = driver.findElements(By.xpath(flyingToList));
		// Thread.sleep(2000);
		int sizeOfTo = flyingToCities.size();
		for (int k = 0; k < sizeOfTo; k++) {
			String text1 = flyingToCities.get(k).getAttribute("textContent");
			// System.out.println(text1);
			// s = "";

			arr = s.concat(text1);
			String[] splitOne = arr.split("\\(");
			// int lent = splitOne.length;
			// System.out.println(lent);
			if (splitOne.length > 2) {
				String[] splitTwoArr = splitOne[2].split("\\),");
				// int len = splitTwoArr.length;
				// System.out.println(len);
				String[] splitThreeArr = splitTwoArr[0].split("\\,");
				int lenThree = splitThreeArr[0].length();
				finalSource = splitThreeArr[0].trim().substring(0, lenThree);
				s = s.concat(finalSource + ",");

			}
			if (splitOne.length <= 2) {
				String[] splitTwo = splitOne[1].split("\\,");
				String[] splitThree = splitTwo[0].split("\\,");
				int lenThree = splitThree[0].length();
				finalSource = splitThree[0].trim().substring(0, lenThree - 1);
				s = s.concat(finalSource + ",");
			}

		}
		xmlStr1 = xmlStr.replace("#origin#", ele);
		xmlStr1 = xmlStr1.replace("#destination#", s);
		System.out.println(xmlStr1);
	}
	/*
	 * @Test public void closingConnection() { System.out.println(
	 * "Browser is going to close!!!"); driver.close(); }
	 */
}
