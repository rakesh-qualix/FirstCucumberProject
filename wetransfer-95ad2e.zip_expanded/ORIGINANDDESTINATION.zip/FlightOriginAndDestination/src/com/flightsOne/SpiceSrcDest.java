package com.flightsOne;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class SpiceSrcDest {
	public WebDriver driver;
	String xmlStr1;
	String xmlStr = "<Table>\n" + "  <Origin>#origin#</Origin>\n" + "<Destination>#destination#</Destination>\n"
			+ "    <EngineID>SpiceJet</EngineID>\n" + "  </Table>";
	String depCity;
	String k = "";
	String s = "";
	String ar;
	@BeforeTest
	public void launchWebsite() {
		driver = new FirefoxDriver();
		driver.get("https://www.spicejet.com/");
		driver.manage().window().maximize();
		System.out.println("Sucessfully opened the website https://www.spicejet.com/");
		System.out.println("==================================");

	}

	@Test(priority = 0)
	public void from() throws InterruptedException {
		String deptCity = "//input[@id='ctl00_mainContent_ddl_originStation1_CTXT']";
		WebElement departure = driver.findElement(By.xpath(deptCity));
		departure.click();
		/*
		 * String listOfDepCity =
		 * ".//*[@id='ctl00_mainContent_ddl_originStation1_CTNR' and @class='search_options_menucontentbg']/div/table/tbody/tr[2]/td[2]/div[3]/div/div/ul/li"
		 * ; WebDriverWait wait = new WebDriverWait(driver, 10); List<WebElement>
		 * depList = wait
		 * .until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath(
		 * listOfDepCity))); int sizeOfDepCity = depList.size(); for (int i = 0; i <
		 * sizeOfDepCity; i++) { String depCity = depList.get(i).getText();
		 * 
		 * s = ""; s = s.concat(depCity); String[] splitted = s.split("\\("); int len =
		 * splitted[1].length(); text = splitted[1].trim().substring(0, len - 1); }
		 */
		List<String> listOfAirportSourceCode = Arrays.asList("AIP", "AMD", "ATQ", "IXB", "BLR", "MAA", "CJB", "DED",
				"DEL", "DHM", "DIB", "GOI", "GOP", "GAU", "HBX", "HYD", "JLR", "JAI", "JSA", "IXJ", "JDH", "IXY", "KNU",
				"KQH", "COK", "CCU", "CCJ", "IXL", "IXM", "IXE", "BOM", "PYG", "PAT", "PNY", "PBD", "IXZ", "PNQ", "RJA",
				"SAG", "IXS", "SXR", "STV", "TRV", "TIR", "TCR", "UDR", "VNS", "VGA", "VTZ", "BKK", "CMB", "DAC", "DXB",
				"HKG", "KBL", "MLE", "MCT");
		int size = listOfAirportSourceCode.size();
	//	System.out.println(size);
		for (int i = 0; i < size; i++) {
			 depCity = listOfAirportSourceCode.get(i);
			 if(i>0) {
				 departure.click();
				 Thread.sleep(1000);
				 departure.clear();
				 Thread.sleep(1000);
			 }
			if (depCity.equalsIgnoreCase("AIP")) {
				departure.sendKeys("Adampur (AIP)");
			}
			else if (depCity.equalsIgnoreCase("RJA")) {
				departure.sendKeys("RJ");
				Thread.sleep(1000);
			}
			else if (depCity.equalsIgnoreCase("PYG")) {
				departure.sendKeys("PY");
				Thread.sleep(1000);
			}
			else if(depCity.equalsIgnoreCase("JAI")) {
				departure.sendKeys("Jaipur (JAI)");
				Thread.sleep(1000);
			}
			else if(depCity.equalsIgnoreCase("PAT")) {
				departure.sendKeys("Patna (PAT)");
				Thread.sleep(1000);
			}
			else {
			departure.sendKeys(depCity);
			Thread.sleep(2000);
			}
			arrivalCity();
		}
		
	}

	@Test(priority = 1)
	public void arrivalCity() throws InterruptedException {
		s="";
		String arrivalList1 = "//select[@id='ctl00_mainContent_ddl_destinationStation1']//option[position()>1]";
		try {
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver, 10);
			List<WebElement> arrivalList = wait
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath(arrivalList1)));
//			Thread.sleep(2000);
		//	List<WebElement> arrivalList=driver.findElements(By.xpath(arrivalList1));
			//Thread.sleep(2000);
			int sizeOfArrCityList = arrivalList.size();
			System.out.println("==================================");
			System.out.println(sizeOfArrCityList);
			System.out.println("==================================");
			for (int i = 0; i < sizeOfArrCityList; i++) {
				String citiesName = arrivalList.get(i).getAttribute("textContent");
				k = "";
				
				ar = k.concat(citiesName);
				String[] arr = ar.split("\\(");
				int length = arr[1].length();
				String arrci = arr[1].trim().substring(0, length - 1);
				s = s.concat(arrci + ",");

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		xmlStr1 = xmlStr.replace("#origin#", depCity);
		xmlStr1 = xmlStr1.replace("#destination#", s);
		System.out.println(xmlStr1);
		Thread.sleep(2000);
		System.out.println("==================================");

	}
}
// }
