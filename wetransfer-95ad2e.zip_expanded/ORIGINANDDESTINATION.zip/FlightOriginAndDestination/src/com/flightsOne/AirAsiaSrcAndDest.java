package com.flightsOne;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class AirAsiaSrcAndDest {
	public WebDriver driver;
	String s = "";
	String listOfOriginCities;
	String orgnCi;
	String t;
	String toArr;
	String xmlStr1;
	String xmlStr = "<Table>\n" + "  <Origin>#origin#</Origin>\n" + "<Destination>#destination#</Destination>\n"
			+ "    <EngineID>AirAsia</EngineID>\n" + "  </Table>";

	@BeforeTest
	public void launchWebsite() throws InterruptedException {
		// driver = new FirefoxDriver();

		/*
		 * System.setProperty("webdriver.chrome.driver",
		 * "C:\\Users\\user\\Desktop\\NewBackup1112018\\newFlight\\FlightOriginAndDestination\\exefiles\\chromedriver.exe"
		 * ); driver=new ChromeDriver();
		 */
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\user\\Desktop\\FlightBackup\\FlightSrcAndDestination\\FlightOriginAndDestination\\exefiles\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.airasia.com");
		driver.manage().window().maximize();
		System.out.println("Sucessfully opened the website https://www.airasia.com/");
		//Thread.sleep(3000);
	}

	@Test
	public void origin() throws InterruptedException {
		 /*Actions actions = new Actions(driver);
	        actions.moveToElement(driver.findElement(By.xpath("//div[@class='input-field lang-en-gb bright padding-less left-input modify-search false']")));
	        actions.click();
	        actions.build().perform();
//	      actions.sendKeys(" ");
*/	       
		WebElement Orgn = driver.findElement(By.xpath("//div[@class='row flight-calendar-container']/div[1]/div[1]/div[1]"));
		try{
			Orgn.click();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		//Thread.sleep(3000);
		// driver.findElement(By.xpath("//span[@id='select2-cb_origins-icon']")).click();
		// Thread.sleep(2000);
		String origin = "//div[@class='dropdown-container']/ul/li";
		List<WebElement> originList = driver.findElements(By.xpath(origin));
		int size = originList.size();
		Thread.sleep(1000);
		// System.out.println(size);
		List<String> listOfIATACode = new ArrayList<String>();
		for (int i = 0; i < size; i++) {
			String orgnCity = originList.get(i).getText();
			listOfIATACode.add(orgnCity);
		}
		for (int j = 0; j < listOfIATACode.size(); j++) {
			if (j > 0) {
				Thread.sleep(1000);
				Orgn.click();
			}

			String DepCity = listOfIATACode.get(j);
			s = "";
			listOfOriginCities = s.concat(DepCity);
			String[] SplittedOrigin = listOfOriginCities.split("\\(");
			int si = SplittedOrigin.length;
			if (si > 2) {
				int sizeOfOrgn = SplittedOrigin[2].length();
				orgnCi = SplittedOrigin[2].trim().substring(0, sizeOfOrgn - 1);
			
				Orgn.sendKeys(orgnCi);
				// actions.build().perform();
				//Orgn.sendKeys(orgnCi);
				Thread.sleep(1000);
				//Orgn.sendKeys(Keys.ENTER);
				Orgn.sendKeys(Keys.ENTER);
				// actions.build().perform();
				Thread.sleep(1000);
			}

			else {
				int sizeOfOrgn = SplittedOrigin[1].length();
				orgnCi = SplittedOrigin[1].trim().substring(0, sizeOfOrgn - 1);
				Thread.sleep(3000);
				Orgn.click();
			//	Orgn.sendKeys(orgnCi);
				Orgn.sendKeys(orgnCi);
				Thread.sleep(1000);
				//Orgn.sendKeys(Keys.ENTER);
				Orgn.sendKeys(Keys.ENTER);
				Thread.sleep(1000);
			}
			destination();
		}

	}

	@Test
	public void destination() throws InterruptedException {

		WebElement dest = driver.findElement(By.xpath("//div[@class='input-field lang-en-gb bright padding-less destination right-input modify-search false']"));
		dest.click();
	//	Thread.sleep(1000);
		String destnList = "//div[@class='dropdown-container']/ul/li";
		List<WebElement> destn = driver.findElements(By.xpath(destnList));
		int sizeOfDestn = destn.size();
		for (int j = 0; j < sizeOfDestn; j++) {
			WebElement destCityTxt = destn.get(j);
			String text = destCityTxt.getText();
			t = "";
			toArr = t.concat(text);
			String[] arrToCity = toArr.split("\\(");
			int sizeOfArr = arrToCity.length;
			if (sizeOfArr > 2) {
				int len = arrToCity[2].length();
				String toCities = arrToCity[2].trim().substring(0, len - 1);
				s = s.concat(toCities + ",");
			} else {
				int len = arrToCity[1].length();
				String toCities = arrToCity[1].trim().substring(0, len - 1);
				s = s.concat(toCities + ",");
			}
		}
		xmlStr1 = xmlStr.replace("#origin#", orgnCi);
		xmlStr1 = xmlStr1.replace("#destination#", s);
		System.out.println(xmlStr1);

	}

	@AfterTest
	public void closingBrowser() {
		driver.close();
		System.out.println("Browser closed successfuly!!!");
	}
}
