package com.flightsOne;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
//We can not automate Captcha
public class ScootSrcAndDest {
	public WebDriver driver;
	@BeforeTest
	public void launchWebsite() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\user\\Desktop\\NewBackup1112018\\newFlight\\FlightOriginAndDestination\\exefiles\\chromedriver.exe");
		driver=new ChromeDriver();
		Thread.sleep(3000);
		  driver.navigate().to("https://www.flyscoot.com/en");
		driver.manage().window().maximize();
		System.out.println("Sucessfully opened the website https://www.flyscoot.com/en");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div[@class='geetest_wait']")).click();
		Thread.sleep(5000);

		/*driver.get("https://www.flyscoot.com/en");
		driver.manage().window().maximize();
		System.out.println("Sucessfully opened the website https://www.flyscoot.com/en");
*/
	}
	@Test
	public void from() {
		
	}
	@Test
	public void to() {
		
	}

}
