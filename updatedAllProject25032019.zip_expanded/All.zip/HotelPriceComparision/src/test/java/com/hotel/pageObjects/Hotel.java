package com.hotel.pageObjects;

import java.awt.RenderingHints.Key;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeoutException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

public class Hotel {
	WebDriver driver;
	String id="";
	@FindBy(xpath=("//input[@id='txtCity']"))
	private WebElement specificHoteName;
	@FindBy(xpath=("//input[@id='btnDiv']"))
	private WebElement searchBtn;
	public Hotel(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}// for initialization of WebElement

	

	@Test
	public void hotelReading() throws TimeoutException, EncryptedDocumentException, InvalidFormatException,
			IOException, InterruptedException {
		
		String filePath = "D:\\NewDelhiHotel.xlsx";
		File file = new File(filePath);
		FileInputStream fis = new FileInputStream(file);
		Workbook wb = WorkbookFactory.create(fis);
		// Read sheet inside the workbook by its name
		Sheet sh = wb.getSheet("Sheet1");
		// Find number of rows in excel file
		// int Firstrow=sh.getFirstRowNum();
		int rowCount = sh.getLastRowNum() - sh.getFirstRowNum();
		 System.out.println(rowCount);
		// Create a loop over all the rows of excel file to read it
		List<String> listOfHotelId = new ArrayList<String>();
		for (int i = 1; i < rowCount; i++) {
			Row row = sh.getRow(i);
			// Create a loop to print cell values in a row
			for (int j = 0; j < row.getLastCellNum(); j++) {
				String hotelId = row.getCell(j).getStringCellValue();
				listOfHotelId.add(hotelId);
				System.out.println(hotelId);
			}

		}
		for (int k = 0; k < listOfHotelId.size(); k++) {
			//String id = listOfHotelId.get(k);
		id = listOfHotelId.get(k);
		Thread.sleep(2000);
		specificHoteName.sendKeys(id);
		Thread.sleep(1000);
		specificHoteName.sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		searchBtn.click();
}
	}
}
