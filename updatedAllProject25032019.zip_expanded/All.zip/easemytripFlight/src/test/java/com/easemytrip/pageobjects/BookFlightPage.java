package com.easemytrip.pageobjects;

import java.util.List;
import java.util.Random;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.easemytrip.generic.WaitStatementLib;

public class BookFlightPage {
	WebDriver driver;

	@FindBy(xpath = ("//div[@class='list divHideShow ng-scope']//div[@class='flgi-rm3']/button"))
	private List<WebElement> interButtons;
	// Path for Booking PageFlight details Link
	@FindBy(xpath = ("//div[@class='d-up']"))
	private List<WebElement> domFlightDetails;
	@FindBy(xpath = ("//div[contains(@id,'divFlightDetail')]/ul/li"))
	private List<WebElement> fetchingFlightFareDetails;
	@FindBy(xpath = ("//div[contains(@id,'divFlightDetailSec')]/div[2]/div/div"))
	private List <WebElement> tabDetails0;
	@FindBy(xpath=("//div[contains(@id,'divFlightDetailSec')]/div[2]/div/div[2]/div"))
	private List<WebElement>tabDetails1;
	@FindBy(xpath=("//div[@class='baggage-info ng-scope']/div[position()>1]"))
	private List<WebElement>baggageTabDetails;
	@FindBy(xpath=("//div[@class='bood mg-btm']"))
	private WebElement canellationTabDetails;
	@FindBy(xpath = ("//button[contains(text(),'Book Now')]"))
	private List<WebElement> domButtons;
	// WebElement for OneWay International FlightDetails
	@FindBy(xpath = ("//form[@id='FrmEmtMdl']/div[9]/div[2]/div[2]/div[3]/div/div/div[2]/span"))
	private List<WebElement> intlFlightDetail;
	@FindBy(xpath = ("//div[@id='ResultDiv']/div/div/div[3]/div[1]/ul/li"))
	private List<WebElement> intlFlightDetailTab;
	@FindBy(xpath = ("//div[@class='li-mn ng-scope']/div[2]/div[1]/div/div"))
	private List<WebElement> baggageInformationTab;// Index 2
	@FindBy(xpath = ("//div[@class='li-mn ng-scope']/div[2]/div/div/div"))
	private List<WebElement> cancellationRuleTab;// Index 3
	// Webelement for Domestic RoundTrip Flight Details
	@FindBy(xpath = ("//div[text()='Flight Detail']"))
	private List<WebElement> domRoundTripFlightDetailsLink;
	@FindBy(xpath = ("//div[@id='divFlightDetailSec54']/ul/li"))
	private List<WebElement> roundTripFareDetailsTabs;
	@FindBy(xpath = ("//div[@id='fd54']/div/div[@class='row']"))
	private List<WebElement> roundTripFareDetailsTabsData;
	@FindBy(xpath = ("//div[@class='row']/div[1]/div[3]/div[1]/div"))
	private List<WebElement> oneGoFlight;
	@FindBy(xpath = ("//div[@class='row']/div[2]/div[3]/div[1]/div"))
	private List<WebElement> returnFlight;
	@FindBy(xpath = ("//div[@id='BtnBookNow']"))
	private WebElement roundTripBookNowBtn;
	@FindBy(xpath = ("//div[@class='inp-b5']//span[text()='1']"))
	private WebElement noOfTravellers;
	// Below path for Review Page Flight Details
	@FindBy(xpath = ("//div[@class='fd-l']/div[1]"))
	private WebElement FlightDetails;
	@FindBy(xpath = ("//div[@class='row bor-b']/div[2]/div/div[2]/button[text()='Book Now']"))
	private List<WebElement> mulCityBookNowBtn;

	public BookFlightPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}

	public void compareTrips(int numberOfWays) throws InterruptedException {
		WaitStatementLib.iWait(2);
		if (numberOfWays == 0) {
			comp();
		} else if (numberOfWays == 1) {
			roundTripComp();
		}
	}
	
	//============================================================
	
	// method for fetching Flight Details for Domestic OneWay
		public void fareDetailsForDomesticOneWay() {
  			Random flightDetails = new Random();
			domFlightDetails.get(flightDetails.nextInt(domFlightDetails.size()-1)).click();
			int sizeOfFaresDetailstab = fetchingFlightFareDetails.size();
			for (int i = 0; i < sizeOfFaresDetailstab; i++) {
				fetchingFlightFareDetails.get(i).click();
				if(i==0){
				for(int k=0;k<tabDetails0.size();k++){
					System.out.println(tabDetails0.get(k).getText());
					System.out.println("============================================================");
				}
				}
				
				else if(i==1){
					for(int l=0;l<tabDetails1.size();l++){
						System.out.println(tabDetails1.get(l).getText());
						System.out.println("============================================================");
					}
				}
				else if (i == 2) {
					
					for (int j = 0; j < baggageTabDetails.size(); j++) {
						String baggageContent = baggageTabDetails.get(j).getText();
						System.out.println(baggageContent);
						System.out.println("============================================================");
					}
			}
				else{
					String cancellationText = canellationTabDetails.getText();
					System.out.println(cancellationText);
					System.out.println("============================================================");
				}
			}
		}
	
	public void fareDetailsForInternationalOneWay() throws InterruptedException {
		Random intlOneWayFlightDetails = new Random();
		intlFlightDetail.get(intlOneWayFlightDetails.nextInt(intlFlightDetail.size())).click();
		Thread.sleep(2000);
		int sizeOfIntlFlightFaresDetailstab = intlFlightDetailTab.size();
		for (int i = 0; i < sizeOfIntlFlightFaresDetailstab; i++) {
			intlFlightDetailTab.get(i).click();
			//String tabName = intlFlightDetailTab.get(i).getText();
	
			if (i == 2) {
					List<WebElement> baggageTabInformationDetails = driver
							.findElements(By.xpath("//div[@class='li-mn ng-scope']/div[2]/div"));
					int sizeOfFlightDetails = baggageTabInformationDetails.size();
					for (int k = 0; k < sizeOfFlightDetails; k++) {
						System.out.println(baggageTabInformationDetails.get(k).getText());
						System.out.println("=======================================================");
					}

				}
			

			if (i == 3) {
				List<WebElement> IntlcancellationRule = driver
						.findElements(By.xpath("//div[@class='bood mg-btm']/div"));
				int sizeOfCancellation = IntlcancellationRule.size();
				for (int k = 0; k < sizeOfCancellation; k++) {
					String dataInRow = IntlcancellationRule.get(k).getText();
					System.out.println(dataInRow );
					System.out.println("=======================================================");

				}
			}

			else {
				List<WebElement> flightInformationTab = driver
						.findElements(By.xpath("//div[contains(@id,'divFlightDetailSec')]/div[2]/div/div"));
				int sizeOfFlightInfDiv = flightInformationTab.size();
				for (int m = 0; m < sizeOfFlightInfDiv; m++) {
					String textForFlightInf = flightInformationTab.get(m).getText();
					System.out.println(textForFlightInf );
					System.out.println("=======================================================");
				}

			}
		}

	}
	
	public void comp() throws InterruptedException {
		WaitStatementLib.iWaitForSecs(driver, 10);
		String pageTitle = driver.getTitle();
		System.out.println(pageTitle);
		if (pageTitle.trim().contains("InternationalOwView2")) {
			try{
			Random ra3 = new Random();
			// Need to call method fareDetailsFor International Here
			// interButtons.size();
			fareDetailsForInternationalOneWay();
			Thread.sleep(5000);
			interButtons.get(ra3.nextInt(interButtons.size())-1).click();
			Thread.sleep(10000);
		//	detailsOfFlight();
			}catch(Exception e){
				System.out.println(e.getMessage());
			}
		}

		else {
			try{
			Random ra3 = new Random();
			fareDetailsForDomesticOneWay();// calling method because fetching domestic flight -->flight details
			Thread.sleep(5000);
			domButtons.get(ra3.nextInt(domButtons.size())-1).click();
		//	detailsOfFlight();
			}catch(Exception e){
				System.out.println(e.getMessage());
			}
		}

	}

	public void clickingGoingFlights() {
		try{
		Random ra4 = new Random();
		WebElement goFlight = oneGoFlight.get(ra4.nextInt(oneGoFlight.size())-1);
		Thread.sleep(5000);
		goFlight.click();
		Thread.sleep(5000);
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}

	public void clickingReturningFlights() {
		try{
		Random ra5 = new Random();
		WebElement retFlight = returnFlight.get(ra5.nextInt(returnFlight.size())-1);
		Thread.sleep(5000);
		retFlight.click();
		Thread.sleep(5000);
		roundTripBookNowBtn.click();
		}catch(Exception e){
			System.out.println(e.getMessage());
			
		}

	}

	public void detailsOfFlight() {
		try {
			String detailsOfSelectedFlight = FlightDetails.getAttribute("textContent");
			// String detailsOfSelectedFlight = FlightDetails.getAttribute("textContent");
			System.out.print("Details of selected Flights are:  " + detailsOfSelectedFlight);
		} catch (Exception e) {
			e.printStackTrace();

		}

	}

	public void roundTripComp() {
		WaitStatementLib.iWait(10);

		String roundTriptDomPageTitle = driver.getTitle();
		System.out.println("Searched url is: " + roundTriptDomPageTitle);
		/*
		 * if (roundTriptDomPageTitle.trim() .contains(
		 * "RoundTrip Lowest Airfare, Flight Tickets, Cheap Air Tickets – EaseMyTrip.com"
		 * )) {
		 */
		/*
		 * if (roundTriptDomPageTitle.trim() .contains(
		 * "RoundTrip Lowest Airfare, Flight Tickets, Cheap Air Tickets  EaseMyTrip.com"
		 * )) {
		 */
		if (roundTriptDomPageTitle.contains("RoundTrip Lowest Airfare")) {
			try {
				clickingGoingFlights();

				clickingReturningFlights();

				//detailsOfFlight();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		else {
			List<WebElement> intlBookNowBtn = driver.findElements(By.xpath("//button[text()='Book Now']"));
			try{
			Random ra6 = new Random();
			Thread.sleep(5000);
			intlBookNowBtn.get(ra6.nextInt(intlBookNowBtn.size())-1).click();
			Thread.sleep(5000);
		//	detailsOfFlight();
			}catch(Exception e){
				System.out.println(e.getMessage());
			}
		}

	}

	/*
	 * public void BookMulCityFlight(){ // String numberOfTraveller =
	 * noOfTravellers.getAttribute("value"); //System.out.println(
	 * "Selected number of traveller is :"+numberOfTraveller); Random ra5 = new
	 * Random(); int mulCityFlight = ra5.nextInt(mulCityBookNowBtn.size());
	 * WaitStatementLib.iWait(2); System.out.println(
	 * "Number of flights found : " + mulCityFlight); WaitStatementLib.iWait(2);
	 * mulCityBookNowBtn.get(mulCityFlight).click(); WaitStatementLib.iWait(2);
	 * detailsOfFlight(); }
	 */
	
	//For handling exception
	/*public boolean isAlertPresent() {
		try {
			Alert a1 = new WebDriverWait(driver, 10).until(ExpectedConditions.alertIsPresent());
			if (a1 != null) {
				System.out.println("Alert is present");
				driver.switchTo().alert().accept();
				clickingGoingFlights();
				clickingReturningFlights();
			}
		} catch (Exception e) {
			e.printStackTrace();
			// System.err.println("Alert isn't present!!");
		}
		return false;

	}*/
}
