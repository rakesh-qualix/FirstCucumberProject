package com.practice;
public class Bank {
	int getROI() {
		return 0;
	}
}
	class SBI extends Bank{
		int getROI(){//Overridden methods
			return 12;
			
		}
		
	}
	class ICICI extends Bank{
		int getROI(){//Overridden methods
			return 13;
			
		}
	}
	class Test{
		public static void main(String[] args){
			SBI s=new SBI();
			s.getROI();
			System.out.println("SBI roi is:"+s.getROI());
			ICICI ic=new ICICI();
			ic.getROI();
			System.out.println("ICICI roi is:"+ic.getROI());
		}
	}


