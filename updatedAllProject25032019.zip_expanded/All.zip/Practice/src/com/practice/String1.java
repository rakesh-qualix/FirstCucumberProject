package com.practice;

public class String1 {

	public static void main(String[] args) {
		String s1="JAVA";//creating string by java string literal  
		char[] ch={'S','T','R','I','N','G'};
		String s2=new String(ch);//converting char array to string
		String s3=new String("Example");//creating java string by new keyword 
		System.out.println(s1+s2+s3);
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);

	}

}
