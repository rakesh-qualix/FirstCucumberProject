
package com.easemytrip.generic;
import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
//import org.testng.annotations.Parameters;
import org.testng.annotations.Parameters;

public class BaseLib  {
	
	public WebDriver driver;
	
	
	@BeforeTest
	//If you want to perform cross browser testing need to take parameter annotation and to change browserName as browser
	@Parameters("browser")
	public void setup(String browser) throws Exception{
//	public void setUp() {
//		String browserName = GenericLib.getValue("browser");
		
		try
		{
		if (browser.equalsIgnoreCase("firefox")) {
			
			
			FirefoxProfile ffprofile = new FirefoxProfile();
			ffprofile.setPreference("dom.webnotifications.enabled", false);
			driver = (new FirefoxDriver(ffprofile));
			
			Reporter.log("Firefox launched !!! Going to execute Tests", true);
			
			
			//Reporter.log("Navigating to www.easemytrip.com", true);
			
		} else if (browser.equalsIgnoreCase("chrome")){

			ChromeOptions options = new ChromeOptions();
			/*//Launch chrome in incognito Mode
			options.addArguments("--incognito");*/
			//To disable notification
			options.addArguments("--disable-notifications");
			System.setProperty("webdriver.chrome.driver", ".\\Drivers\\chromedriver.exe");
			driver = new ChromeDriver(options);
			Reporter.log("Chrome Launched", true);
		} 
		driver.manage().window().maximize();
		WaitStatementLib.iWaitForSecs(driver, 2);
		driver.get(GenericLib.getValue("testurl"));
		Reporter.log(" Please Wait!!!!!!---> Browser is navigating to www.easemytrip.com!!!!!<----", true);
		
		//To check Subscribing Popup
		Thread.sleep(2000);
	/*	if(driver.switchTo().frame("iframe") != null){
		//if(driver.findElement(By.xpath("//div[@id='container_id']/div[2]/p[4]/font")).isDisplayed()){
			
			driver.findElement(By.xpath("//a[@id='close_btn']/span")).click();
			//Thread.sleep(1000);
		}*/
		}catch(Exception e){
			System.out.println(e.getMessage());
	
		}
		
	}
	
@AfterMethod

	public void getScreen(ITestResult result) throws IOException {

		try {
			if (result.getStatus() == ITestResult.FAILURE) {
				String fileName = result.getMethod().getMethodName();
				ScreenshotLib slib = new ScreenshotLib();
				slib.takeScreenshot(driver, fileName);
				Reporter.log("Screenshot has been taken", true);
				/*fetch test file 
				 * create request and set test file data
				 * hit/call mail service
				 * 
				 * 
				 */
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
}
/*//create MAil service
public void mailService(String requestDate,String Url){
	


}*/
		

	@AfterTest
	public void tearDown() throws InterruptedException {
	Thread.sleep(5000);
		//System.out.println("Going to search other Sector....");
		driver.close();
		//Reporter.log("Browser closed", true);
	}
	
	

}
