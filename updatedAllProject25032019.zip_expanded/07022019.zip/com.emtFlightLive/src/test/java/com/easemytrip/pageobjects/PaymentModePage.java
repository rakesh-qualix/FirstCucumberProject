package com.easemytrip.pageobjects;

import java.util.List;
import java.util.Random;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.easemytrip.generic.WaitStatementLib;

public class PaymentModePage {
	WebDriver driver;
	@FindBy(xpath = ("//div[@class='fd-l2']/div[1]"))
	private WebElement travelersDetails;
	@FindBy(xpath = ("//div[@class='stickyheader']/div[1]"))
	private WebElement priceSummary;
	// @FindBy(xpath = ("//div[@class='pymnt-bx-lft']/div[position()>1]"))
	@FindBy(xpath = ("//div[@class='pymnt-bx-lft']/div[@class!='sv-dtl' and @class!='bharatqr']"))
	private List<WebElement> paymentMode;// TOTAL NUMBER OF PAYMENT OPTIONS ARE
											// 7
	// Storing elements for Debit and credit cards
	@FindBy(xpath = ("//input[@id='CC']"))
	private WebElement cardNumbrer;
	@FindBy(xpath = ("//input[@id='CCN']"))
	private WebElement cardHolderName;
	@FindBy(xpath = ("//select[@id='CCMM']"))
	private WebElement expMonth;
	@FindBy(xpath = ("//select[@id='CCYYYY']"))
	private WebElement expYear;
	@FindBy(xpath = ("//input[@id='CCCVV']"))
	private WebElement cardCvvNumber;
	@FindBy(xpath = ("//div[@id='DivDebitCardPanel']//div[10][text()='Make Payment']"))
	private WebElement makePaymentForDCCard;
	// Storing WebElement and List<WebElement> for NetBanking
	@FindBy(xpath = ("//label[@id='rdoICIB'] "))
	private WebElement iciciBank;
	@FindBy(xpath = ("//div[@class='mk-pym3']"))
	private WebElement paymentBtnForNetbanking;
	// Icici Internet Banking Details
	// @FindBy(xpath = ("//input[@id='AuthenticationFG.USER_PRINCIPAL']"))
	@FindBy(xpath = ("//input[@name='AuthenticationFG.USER_PRINCIPAL']"))
	private WebElement userId;
	// @FindBy(xpath = ("//input[@id='AuthenticationFG.ACCESS_CODE']"))
	@FindBy(xpath = ("//input[@class='m_loginPass']"))
	private WebElement password;
	// @FindBy(xpath = ("//input[@id='VALIDATE_CREDENTIALS']"))
	@FindBy(xpath = ("//input[@class='login_button']"))
	private WebElement loginBtn;
	// Storing WebElements for MyWallet
	@FindBy(xpath = ("//div[@class='radi-bt4']/div[@class!='clr']"))
	private List<WebElement> myWallet;
	@FindBy(xpath = ("//div[@class='mk-pym4']"))
	private WebElement walletMakePayment;
	// WebElements for MobiKwik Money Wallet

	@FindBy(xpath = ("//div[@id='signinlyr']/h2"))
	private WebElement mobikwikText;
	@FindBy(xpath = ("//input[@id='logininput']"))
	private WebElement mobikwikMobile;
	@FindBy(xpath = ("//input[@id='pwdsignininput']"))
	private WebElement mobikwikPassword;
	@FindBy(xpath = ("//input[@id='signinFrm']"))
	private WebElement mobikwikSubmitBtn;
	@FindBy(xpath = ("//a[@id='DC']"))
	private WebElement debitCreditCard;
	@FindBy(xpath = ("//input[@id='cc_number']"))
	private WebElement cardNo;
	@FindBy(xpath = ("//select[@id='cc_exp_month']"))
	private WebElement cardMonth;
	@FindBy(xpath = ("//select[@id='cc_exp_year']"))
	private WebElement cardYear;
	@FindBy(xpath = "//input[@id='cc_cvv']")
	private WebElement cardCvv;
	@FindBy(xpath = ("//input[@id='paymentdivbutton']"))
	private WebElement payNowBtn;
	@FindBy(xpath = "//button[@id='authsubmit']")
	private WebElement continueToFailTransaction;
	@FindBy(xpath = ("//input[@id='back']"))
	private WebElement backToMerchantSideBtn;
	// Element for PhonePayVerificationText under Wallet
	@FindBy(xpath = ("//div[@id='ms-header-content']/div/h1"))
	private WebElement verifyPhonePayTextUnderWallet;

	// WebElements for Airtel Money Wallet
	@FindBy(xpath = ("//div[@class='login-panel']/h2"))
	private WebElement verifyTextForAirtelWallet;
	@FindBy(xpath = ("//input[@id='usernameInput']"))
	private WebElement MobileNumber;
	@FindBy(xpath = ("//a[text()='LOGIN WITH OTP']"))
	private WebElement loginWithOTP;
	@FindBy(xpath = ("//button[@class='cross-right']"))
	private WebElement crossSign;
	@FindBy(xpath = ("//input[@id='mpinInput']"))
	private WebElement mPin;
	// @FindBy(xpath=("//button[text()='LOGIN']"))
	@FindBy(xpath = ("//button[@class='btn btn-primary m-b-25']"))
	private WebElement airtelLoginBtn;
	@FindBy(xpath = ("//button[text()='Load Money']"))
	private WebElement loadMoneyToAirtel;
	@FindBy(xpath = ("//div[@class='form-wrapper']/div[2]/div/div/div/ul/li"))
	private List<WebElement> cards;
	@FindBy(xpath = ("//input[@name='CCNumber']"))
	private WebElement HdfcCardNumber;
	@FindBy(xpath = ("//input[@id='ccName']"))
	private WebElement hdfcCardHolderName;
	@FindBy(xpath = ("//input[@name='expiryMonth']"))
	private List<WebElement> mm;
	@FindBy(xpath = ("//input[@id='ccExpiryYear']"))
	private WebElement yyyy;
	@FindBy(xpath = ("//input[@id='ccCvv']"))
	private WebElement enterCVV;
	@FindBy(xpath = ("//a[text()='Cancel']"))
	private WebElement cancelTransaction;

	// Storing WebElement for AmazonPay Wallet
	@FindBy(xpath = ("//div[@id='authportal-main-section']/div[2]/div/div/form/div/div/div/h1"))
	private WebElement verifyTextForAmazonPayWallet;
	@FindBy(xpath = ("//input[@id='ap_email']"))
	private WebElement emailOrMobilePhoneNumber;
	@FindBy(xpath = ("//input[@id='ap_password']"))
	private WebElement amazonAppPassword;
	@FindBy(xpath = ("//input[@id='signInSubmit']"))
	private WebElement amazonAppLoginBtn;
	@FindBy(xpath = ("//div[@id='radio' and contains(@class,'a-radio a-radio-fancy NetBanking') ]/label/i"))
	private WebElement radioBtnForNetBanking;
	@FindBy(xpath = ("//span[@id='netbankingSelect']/span/span"))
	private WebElement chooseBankForNetBanking;
	@FindBy(xpath = ("//div[@class='a-popover-wrapper']/div/ul/li"))
	private List<WebElement> bankList;
	@FindBy(xpath = ("//span[@id='pay_now_desktop']/span/input"))
	private WebElement payNowBtnForAmazonApp;
	@FindBy(xpath = ("//input[@id='CANCEL_SHOPPING_MALL_PMT']"))
	private WebElement IciciBankTransactionCancelBtn;

	// Storing WebElement for ePayLater Wallet
	@FindBy(xpath = ("//div[@class='right_inner']/p"))
	private WebElement verifyTextForSignInForEPayLater;
	@FindBy(xpath = ("//div[@class='form-group select_enter mobile_error']"))
	private WebElement ePayLaterMobile;
	@FindBy(xpath = ("//input[@id='continueButton']"))
	private WebElement ePayLaterContinueBtn;
	@FindBy(xpath = ("//a[@id='cancelButton']"))
	private WebElement ePayLaterCancelBtn;

	// Storing WebElement for verifyTextForUPI payment
	@FindBy(xpath = ("//input[@id='txtUpi']"))
	private WebElement virtualAddressForverifyTextForUPI;
	@FindBy(xpath = ("//div[@class='pymnt-bx-rgt5']/div//div[5]"))
	private WebElement makePaymentForverifyTextForUPI;
	// Storing WebElement for verifyTextForPhonePay Option
	@FindBy(xpath = ("//span[@id='PhonePeBtn']"))
	private WebElement makePaymentForverifyTextForPhonePayOpt;
	/*
	 * // Storing WebElement for Bharat QR
	 * 
	 * @FindBy(xpath = (
	 * "//div[@class='bor mar20 m-bt']/div[3]/div[8]/div[1]/div[3]")) private
	 * WebElement makePaymentForverifyTextForBharatQR;
	 */
	// Storing WebElement for EMI
	@FindBy(xpath = ("//select[@id='drpEMIBank']/option"))
	private List<WebElement> emiBankOptions;
	@FindBy(xpath = ("//input[@id='emi_opt_1']"))
	private WebElement emiPlan;
	@FindBy(xpath = ("//input[@id='CC1']"))
	private WebElement creditCardNo;
	@FindBy(xpath = ("//input[@id='CCN1']"))
	private WebElement creditCardHolderName;
	@FindBy(xpath = ("//select[@id='CCMM1']"))
	private WebElement creditCardExpiryMonth;
	@FindBy(xpath = ("//select[@id='CCYYYY1']"))
	private WebElement creditCardExpiryYear;
	@FindBy(xpath = ("//input[@id='CCCVV1']"))
	private WebElement credirCardCvvNo;
	@FindBy(xpath = ("//div[@class='mk-pym']"))
	private List<WebElement> creditCardMakePayment;
	// Storing WebElement for PhonePay transaction page
	@FindBy(xpath = ("//input[@id='mobileNumber']"))
	private WebElement mobileNumberForPhonePay;
	@FindBy(xpath = ("//button[@id='onboardingFormSubmitBtn']"))
	private WebElement sendBtn;
	@FindBy(xpath = ("//div[text()='Enter Your Card No.']"))
	// @FindBy(xpath=("//div[@class='inp-mnu']"))
	private WebElement verifyTextForDebitCreditCard;
	@FindBy(xpath = ("//div[text()='SELECT POPULAR BANKS']"))
	private WebElement verifyTextForNetBanking;
	@FindBy(xpath = ("//div[text()='SELECT YOUR WALLET']"))
	private WebElement verifyTextForMyWallet;
	@FindBy(xpath = ("//img[@alt='UPI Step']"))
	private WebElement verifyTextForUPI;
	@FindBy(xpath = ("//div[@class='upi-m']/div[3]//span[text()='0']"))
	private WebElement verifyTextForPhonePay;
	@FindBy(xpath = ("//div[@class='bharat-qr-visa']"))
	private WebElement verifyTextForBharatQR;
	@FindBy(xpath = ("html/body/form/div[9]/div[4]/div/div[3]/div[2]/div[3]/div[2]/div[3]/div[8]/div/div[3]/span"))
	private WebElement paymentBtnForBhQr;
	@FindBy(xpath = ("//div[text()='SELECT  BANKS']"))
	private WebElement verifyTextForEmi;
	// For click on cancel button when payment is going to made by Debit/credit
	// card
	@FindBy(xpath = ("//div[@id='buttons']/a[2]"))
	private WebElement cancelBtn;
	// getting text for convenience fees

	// Phone Pay login button
	@FindBy(xpath = ("//button[@id='onboardingFormSubmitBtn']"))
	private WebElement phonePayLoginBtn;
	// Phone Pay Card Webelement
	@FindBy(xpath = ("//input[@id='cardNumber']"))
	private WebElement emtHdfcCardNumber;
	@FindBy(xpath = ("//select[@id='selMonth']"))
	private WebElement month;
	@FindBy(xpath = ("//select[@id='selYear']"))
	private WebElement Year;
	// @FindBy(xpath=("//input[@id='cvvNumber']"))
	@FindBy(xpath = ("//input[@id='saved-card-cvv-0']"))
	private WebElement cvv;
	@FindBy(xpath = ("//button[@id='paySubmitButton']"))
	private WebElement payBtn;
	@FindBy(xpath = ("//input[@id='txtOtpPassword']"))
	private WebElement phonePayOtp;
	@FindBy(xpath = ("//button[@id='cmdSubmit']"))
	private WebElement phonePaySubmitBtn;
	// Storing WebElement for Paypal Payment option
	@FindBy(xpath = ("//div[@class='paypal_btn']"))
	private WebElement paypalBtn;
	@FindBy(xpath = ("//div[@class='pym']"))
	private WebElement verifyCurrency;
	@FindBy(xpath = ("//a[@class='btn full ng-binding']"))
	private WebElement payPalLogInBtn;
	@FindBy(xpath = ("//input[@id='email']"))
	private WebElement payPalEmailAddress;
	@FindBy(xpath = ("//input[@id='password']"))
	private WebElement payPalPassword;
	@FindBy(xpath = ("//button[@id='btnLogin']"))
	private WebElement payPalLogInBtn1;
	@FindBy(xpath = ("//span[text()='Cancel and return to EASY TRIP PLANNERS PRIVATE LIMITED']"))
	private WebElement payPalCancelLink;

	@FindBy(xpath = ("//input[@id='cc']"))
	private WebElement debitOrCreditCardNumber;
	@FindBy(xpath = ("//input[@id='expiry_value']"))
	private WebElement expiryDate;
	@FindBy(xpath = ("//input[@id='cvv']"))
	private WebElement cvvNumber;
	@FindBy(xpath = ("//input[@id='firstName']"))
	private WebElement firstName;
	@FindBy(xpath = ("//input[@id='lastName']"))
	private WebElement lastName;
	@FindBy(xpath = ("//input[@id='telephone']"))
	private WebElement phoneNumber;
	@FindBy(xpath = ("//input[@id='billingLine1']"))
	private WebElement billingAddress1;
	@FindBy(xpath = ("//input[@id='billingLine2']"))
	private WebElement billingAddress2;
	@FindBy(xpath = ("//input[@id='billingCity']"))
	private WebElement billingTownOrCity;
	@FindBy(xpath = ("//select[@id='billingState']"))
	private WebElement billingState;
	@FindBy(xpath = ("//input[@id='billingPostalCode']"))
	private WebElement postalCode;
	@FindBy(xpath = ("//input[@id='email']"))
	private WebElement emailAddress;
	@FindBy(xpath = ("//input[@id='password']"))
	private WebElement emailPassword;
	@FindBy(xpath = ("//input[@id='dobText']"))
	private WebElement dateOfBirth;
	@FindBy(xpath = ("//button[@id='guestSubmit']"))
	private WebElement agreeAndpayBtn;
	// To print fail transaction Ticket
	@FindBy(xpath = ("//div[@id='divConfirmTicket']"))
	private WebElement ticket;

	public PaymentModePage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}// for initialization of WebElement

	public void fetchingTravelerDetails() {
		WaitStatementLib.iWait(2);
		String detailsOfTravelers = travelersDetails.getAttribute("textContent");
		System.out.println("Entered Traveller Details are: " + detailsOfTravelers);
	}

	public void fetchingPrice() {
		WaitStatementLib.iWait(2);
		String totalPrice = priceSummary.getText();
		System.out.println("Total Fare calculated  is given Below :" + totalPrice);
	}

	public void GetFailedtransaction() {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		String TicketText = ticket.getText();
		System.out.print(TicketText + "\n");
	}

	public void selectingPaymentOptions() {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e1) {

			e1.printStackTrace();
		}
		Random ra1 = new Random();
		int rondomNumber1 = ra1.nextInt(paymentMode.size());
		 WaitStatementLib.iWait(5);
		WebElement NameOfPaymentMethod = paymentMode.get(rondomNumber1);
		//WebElement NameOfPaymentMethod = paymentMode.get(2);
		// WaitStatementLib.iWait(5);
		NameOfPaymentMethod.click();
		 WaitStatementLib.iWait(2);
		
		System.out.println("Selected payment method is : " + NameOfPaymentMethod.getText());
		WaitStatementLib.iWait(2);
	}

	public void debitCardPayment() throws InterruptedException {
		//Thread.sleep(3000);
		cardNumbrer.click();
		cardNumbrer.sendKeys("5546232920724480");
		cardHolderName.click();
		cardHolderName.sendKeys("RAKESH KUMAR JHA");
		Select sel1 = new Select(expMonth);
		sel1.selectByValue("06");
		sel1 = new Select(expYear);
		sel1.selectByValue("2023");
		cardCvvNumber.sendKeys("854");
		makePaymentForDCCard.click();
		WaitStatementLib.iWait(5);
		driver.findElement(By.xpath("//button[@id='authsubmit']")).click();
		Thread.sleep(5000);
		GetFailedtransaction();
		System.out.println("***************======================****************");
		System.out.println("***************======================****************");

	}

	public void netBankingPayment() throws InterruptedException {
		iciciBank.click();
		WaitStatementLib.iWait(2);
		paymentBtnForNetbanking.click();
		WaitStatementLib.iWait(2);
		// userId.click();
		userId.sendKeys("RAKESHJHAJ06");
		// password.click();
		password.sendKeys("EASEMYTRIP@2018");
		// WaitStatementLib.eWaitForVisibility(driver, 10, loginBtn);
		loginBtn.click();
		WaitStatementLib.iWait(5);
		driver.navigate().back();
		Thread.sleep(1000);
		driver.navigate().back();
		Thread.sleep(10000);
		GetFailedtransaction();
		System.out.println("***************======================****************");
		System.out.println("***************======================****************");
		/*
		 * // Handling browser popup Set<String> handles =
		 * driver.getWindowHandles(); Iterator<String> it = handles.iterator();
		 * // String parent = it.next(); String child = it.next();
		 * driver.switchTo().window(child);
		 */
		/*
		 * String TicketText = ticket.getText();
		 * System.out.print(TicketText+"\n");
		 */
		// perform actions on child windo
		// driver.close(); // only for child wondow
	}

	public boolean isMobikwik(WebElement mobikwikText) {
		try {
			if (mobikwikText.isDisplayed()) {
				return true;
			}
		} catch (Exception e) {

		}
		return false;
	}

	public boolean isPhonePay(WebElement verifyPhonePayTextUnderWallet) {
		try {
			if (verifyPhonePayTextUnderWallet.isDisplayed()) {
				return true;

			}
		} catch (Exception e) {

		}
		return false;
	}

	public boolean isAirtel(WebElement verifyTextForAirtelWallet) {
		try {
			if (verifyTextForAirtelWallet.isDisplayed()) {
				return true;
			}
		} catch (Exception e) {

		}
		return false;
	}

	public boolean isAmazonPay(WebElement verifyTextForAmazonPayWallet) {
		try {
			if (verifyTextForAmazonPayWallet.isDisplayed()) {
				return true;
			}
		} catch (Exception e) {

		}
		return false;
	}

	public boolean isePayLater(WebElement verifyTextForSignInForEPayLater) {
		try {
			if (verifyTextForSignInForEPayLater.isDisplayed()) {
				return true;
			}
		} catch (Exception e) {

		}
		return false;
	}

	public void walletPayment() {
		try {
			WaitStatementLib.iWait(2);
			Random Wallet = new Random();
			int rondomWallet = Wallet.nextInt(myWallet.size());
			WebElement walletPaymentMethod = myWallet.get(rondomWallet);
			// WebElement walletPaymentMethod = myWallet.get(1);
			Thread.sleep(5000);
			walletPaymentMethod.click();
			walletMakePayment.click();
			Thread.sleep(3000);
			paymentDoneByWallet();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void paymentDoneByWallet() {
		if (isMobikwik(mobikwikText)) {
			mobikwikWalletPayment();
		} else if (isPhonePay(verifyPhonePayTextUnderWallet)) {
			phonePayWalletpayment();
		} else if (isAirtel(verifyTextForAirtelWallet)) {
			airtelWalletPayment();
		} else if (isAmazonPay(verifyTextForAmazonPayWallet)) {
			amazonPayWalletPayment();
		} else if (isePayLater(verifyTextForSignInForEPayLater)) {
			ePayLaterWalletPayment();
		}

	}

	public void mobikwikWalletPayment() {
		try {
			System.out.println("Selected Wallet is Mobikwik");
			Thread.sleep(1000);
			mobikwikMobile.click();
			Thread.sleep(1000);
			mobikwikMobile.clear();
			Thread.sleep(1000);
			mobikwikMobile.sendKeys("jharakesh1.1990@gmail.com");
			Thread.sleep(1000);
			mobikwikPassword.click();
			Thread.sleep(1000);
			mobikwikPassword.sendKeys("rakeshjha1990");
			Thread.sleep(1000);
			mobikwikSubmitBtn.click();
			Thread.sleep(2000);
			debitCreditCard.click();
			Thread.sleep(2000);
			cardNo.click();
			Thread.sleep(1000);
			cardNo.sendKeys("5546232920724480");
			Thread.sleep(1000);
			Select selMobikwik = new Select(cardMonth);
			selMobikwik.selectByVisibleText("06");
			selMobikwik = new Select(cardYear);
			selMobikwik.selectByValue("2023");
			cardCvv.sendKeys("854");
			Thread.sleep(2000);
			payNowBtn.click();
			Thread.sleep(6000);
			continueToFailTransaction.click();
			Thread.sleep(6000);
			backToMerchantSideBtn.click();
			Thread.sleep(6000);
			GetFailedtransaction();
			System.out.println("***************======================****************");
			System.out.println("***************======================****************");
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	public void phonePayWalletpayment() {
		try {
			System.out.println("Selected Wallet is PhonePay");
			mobileNumberForPhonePay.click();
			WaitStatementLib.iWait(2);
			try{
			//mobileNumberForPhonePay.clear();
			mobileNumberForPhonePay.sendKeys(Keys.chord(Keys.CONTROL,"a", Keys.DELETE));
			WaitStatementLib.iWait(2);
			//Assert.fail("Not able to clear!!!");
			}catch(Exception e){
				e.printStackTrace();
			}
			mobileNumberForPhonePay.sendKeys("9971997901");
			WaitStatementLib.iWait(5);
			sendBtn.click();
			WaitStatementLib.iWait(5);
			System.err.println("Cancel transaction without entering OTP!!!");
			System.out.println("===========================================");
			/*
			 * driver.navigate().back(); Thread.sleep(5000);
			 */
			// GetFailedtransaction();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void airtelWalletPayment() {
		try {
			MobileNumber.click();
			WaitStatementLib.iWait(2);
			MobileNumber.clear();
			WaitStatementLib.iWait(2);
			MobileNumber.sendKeys("9971997901");
			WaitStatementLib.iWait(2);
			loginWithOTP.click();
			WaitStatementLib.iWait(10);
			crossSign.click();
			Thread.sleep(5000);
			GetFailedtransaction();
			System.out.println("***************======================****************");
			System.out.println("***************======================****************");
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	public void ePayLaterWalletPayment() {
		try {
			/*
			 * ePayLaterMobile.click(); ePayLaterMobile.clear();
			 * ePayLaterMobile.sendKeys("9971997901");
			 * ePayLaterContinueBtn.click();
			 */
			// Thread.sleep(2000);
			ePayLaterCancelBtn.click();
			Thread.sleep(1000);
			GetFailedtransaction();
			System.out.println("***************======================****************");
			System.out.println("***************======================****************");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void amazonPayWalletPayment() {
		try {
			emailOrMobilePhoneNumber.click();
			emailOrMobilePhoneNumber.sendKeys("rakeshit0913@gmail.com");
			amazonAppPassword.click();
			amazonAppPassword.sendKeys("9971997901");
			amazonAppLoginBtn.click();
			Thread.sleep(5000);
			radioBtnForNetBanking.click();
			Thread.sleep(1000);
			chooseBankForNetBanking.click();
			bankList.get(2).click();
			Thread.sleep(2000);
			payNowBtnForAmazonApp.click();
			userId.sendKeys("RAKESHJHAJ06");
			password.sendKeys("EASEMYTRIP@2018");
			loginBtn.click();
			WaitStatementLib.iWait(5);
			IciciBankTransactionCancelBtn.click();
			GetFailedtransaction();
			System.out.println("***************======================****************");
			System.out.println("***************======================****************");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void uPIPayment() throws InterruptedException {
		virtualAddressForverifyTextForUPI.click();
		Thread.sleep(5000);
		virtualAddressForverifyTextForUPI.sendKeys("9971997901@airtel");
		Thread.sleep(3000);
		makePaymentForverifyTextForUPI.click();
		Thread.sleep(10000);
		driver.navigate().refresh();
		Thread.sleep(5000);
		/*
		 * Alert alert = driver.switchTo().alert(); alert.accept();
		 * Thread.sleep(5000);
		 */
		Thread.sleep(5000);
		GetFailedtransaction();
		System.out.println("***************======================****************");
		System.out.println("***************======================****************");

	}

	public void phonePayOptionPayment() throws InterruptedException {
		// Enable code for saved card only
		makePaymentForverifyTextForPhonePayOpt.click();
		Thread.sleep(5000);
		mobileNumberForPhonePay.click();
		WaitStatementLib.iWait(2);
		//mobileNumberForPhonePay.clear();
		mobileNumberForPhonePay.sendKeys(Keys.chord(Keys.CONTROL,"a", Keys.DELETE));
		WaitStatementLib.iWait(2);
		//Assert.fail("Not able to clear!!!");
		mobileNumberForPhonePay.sendKeys("9971997901");
		WaitStatementLib.iWait(5);
		WaitStatementLib.iWait(2);
		mobileNumberForPhonePay.sendKeys("9971997901");
		WaitStatementLib.iWait(5);
		sendBtn.click();
		WaitStatementLib.iWait(5);
		System.err.println("Cancel transaction without entering OTP!!!");
		System.out.println("===========================================");
		/*
		 * WaitStatementLib.iWait(5); driver.navigate().back();
		 * Thread.sleep(5000);
		 */
		// GetFailedtransaction();

	}

	/*
	 * public void bharatQRPayment() { // WebElement makePaymentBtn =
	 * paymentBtnForBhQr.get(1); // makePaymentBtn.click();
	 * paymentBtnForBhQr.click(); WaitStatementLib.iWait(2); System.out.println(
	 * "clicked on payment button...."); }
	 */
	public void emiPayment() throws InterruptedException {
		WebElement bankName = emiBankOptions.get(1);
		bankName.click();
		WaitStatementLib.iWait(3);
		emiPlan.click();
		WaitStatementLib.iWait(5);
		creditCardNo.click();
		creditCardNo.sendKeys("4375514558134002");
		creditCardHolderName.click();
		creditCardHolderName.sendKeys("Rakesh Kumar Jha");
		Select sel2 = new Select(creditCardExpiryMonth);
		sel2.selectByVisibleText("09");
		sel2 = new Select(creditCardExpiryYear);
		sel2.selectByVisibleText("2020");
		credirCardCvvNo.click();
		credirCardCvvNo.sendKeys("144");
		WaitStatementLib.iWait(5);
		creditCardMakePayment.get(1).click();
		WaitStatementLib.iWait(10);
		driver.navigate().back();
		Thread.sleep(5000);
		GetFailedtransaction();
		System.out.println("***************======================****************");
		System.out.println("***************======================****************");

	}

	public void payPalPayment() throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, 20);
		WebElement payWithPaypal = wait
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='paypal_btn']")));
		payWithPaypal.click();
		Thread.sleep(8000);
		WebDriverWait wait1 = new WebDriverWait(driver, 20);
		WebElement logInToPayPal = wait1
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@class='btn full ng-binding']")));
		Thread.sleep(5000);
		logInToPayPal.click();

		Thread.sleep(5000);
		payPalEmailAddress.clear();
		payPalEmailAddress.sendKeys("kumar.rakeshjha7901@gmail.com");
		payPalPassword.sendKeys("rakeshjha1990");
		payPalLogInBtn1.click();
		Thread.sleep(5000);
		WebDriverWait waitP = new WebDriverWait(driver, 20);
		Thread.sleep(2000);
		waitP.until(ExpectedConditions.elementToBeClickable(payPalCancelLink)).click();
		
		// payPalCancelLink.click();
		Thread.sleep(10000);
		GetFailedtransaction();

	}

	public boolean isDebitCard(WebElement verifyTextForDebitCreditCard) {

		try {
			WaitStatementLib.iWait(5);
			if (verifyTextForDebitCreditCard.isDisplayed()) {

				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();

		}
		return false;

	}

	public boolean isInternetBanking(WebElement verifyTextForNetBanking) {

		try {
			if (verifyTextForNetBanking.isDisplayed()) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();

		}
		return false;

	}

	public boolean isWallet(WebElement verifyTextForMyWallet) {

		try {
			if (verifyTextForMyWallet.isDisplayed()) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();

		}
		return false;

	}

	public boolean isUpi(WebElement verifyTextForUPI) {

		try {
			if (verifyTextForUPI.isDisplayed()) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();

		}
		return false;

	}
	// Not available for payment method
	/*
	 * public boolean isQR(WebElement verifyTextForBharatQR) {
	 * 
	 * try { if (verifyTextForBharatQR.isDisplayed()) { return true; } } catch
	 * (Exception e) { e.printStackTrace();
	 * 
	 * } return false;
	 * 
	 * }
	 */

	public boolean isEmi(WebElement verifyTextForEmi) {

		try {
			if (verifyTextForEmi.isDisplayed()) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();

		}
		return false;

	}

	public boolean isPayPalPayment(WebElement verifyCurrency) {
		try {
			if (verifyCurrency.isDisplayed()) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;

	}

	public void findingClickedPaymentOption() throws InterruptedException {
		// WaitStatementLib.iWait(5);
		if (isDebitCard(verifyTextForDebitCreditCard)) {
			// if (verifyTextForDebitCreditCard.isDisplayed()) {
			System.out.println("Going to enter Debit card details:");
			debitCardPayment();
		} else if (isInternetBanking(verifyTextForNetBanking)) {
			System.out.println("Going to enter internet banking details:");
			netBankingPayment();
		} else if (isWallet(verifyTextForMyWallet)) {
			System.out.println("Going to enter Wallet details:");
			walletPayment();
		} else if (isUpi(verifyTextForUPI)) {
			System.out.println("Going to enter verifyTextForUPI details:");
			uPIPayment();
		}

		/*
		 * else if (isQR(verifyTextForBharatQR)) { System.out.println(
		 * "Going to enter verifyTextForBharatQR details:"); bharatQRPayment();
		 * }
		 */
		else if (isEmi(verifyTextForEmi)) {
			emiPayment();
		} else if (isPayPalPayment(verifyCurrency)) {
			System.out.println("Going to make Payment through Paypal");
			payPalPayment();
		} else {
			System.out.println("Going to enter verifyTextForPhonePay details:");
			phonePayOptionPayment();
		}

	}
}
