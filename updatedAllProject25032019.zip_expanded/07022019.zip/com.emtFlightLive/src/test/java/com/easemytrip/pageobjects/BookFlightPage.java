package com.easemytrip.pageobjects;
import java.util.List;
import java.util.Random;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import com.easemytrip.generic.WaitStatementLib;

public class BookFlightPage {
	WebDriver driver;

	@FindBy(xpath = ("//div[@class='list divHideShow ng-scope']//div[@class='flgi-rm3']/button"))
	private List<WebElement> interButtons;
	// Path for Booking PageFlight details Link
	@FindBy(xpath = ("//div[@id='ResultDiv']/div/div/div[3]/div/div/div[3]/div[1]/div"))
	private List<WebElement> domFlightDetails;
	@FindBy(xpath = ("//div[contains(@id,'divFlightDetail')]/ul/li"))
	private List<WebElement> fetchingFlightFareDetails;
	@FindBy(xpath = ("//div[contains(@id,'divFlightDetailSec')]/div[2]/div/div"))
	private List<WebElement> tabDetails0;
	@FindBy(xpath = ("//div[contains(@id,'divFlightDetailSec')]/div[2]/div/div[2]/div"))
	private List<WebElement> tabDetails1;
	@FindBy(xpath = ("//div[@class='baggage-info ng-scope']/div[position()>1]"))
	private List<WebElement> baggageTabDetails;
	@FindBy(xpath = ("//div[@class='bood mg-btm']"))
	private WebElement canellationTabDetails;
	@FindBy(xpath = ("//div[@id='ResultDiv']/div/div/div[3]/div/div/div[1]/div[6]//button[text()='Book Now']"))
	private List<WebElement> domButtons;
	// WebElement for OneWay International FlightDetails
	@FindBy(xpath = ("//form[@id='FrmEmtMdl']/div[9]/div[2]/div[2]/div[3]/div/div/div[2]/span"))
	private List<WebElement> intlFlightDetail;
	@FindBy(xpath = ("//div[@id='ResultDiv']/div/div/div[3]/div[1]/ul/li"))
	private List<WebElement> intlFlightDetailTab;
	@FindBy(xpath = ("//div[@class='li-mn ng-scope']/div[2]/div[1]/div/div"))
	private List<WebElement> baggageInformationTab;// Index 2
	@FindBy(xpath = ("//div[@class='li-mn ng-scope']/div[2]/div/div/div"))
	private List<WebElement> cancellationRuleTab;// Index 3
	// Webelement for Domestic RoundTrip Flight Details
	@FindBy(xpath = ("//div[@class='col-md-12 no-padd col-sm-12']/div[1]"))
	private List<WebElement> domRoundTripOneGoFlightDetailsLink;
	@FindBy(xpath = ("//div[@class='col-sm-12 no-padd col-md-12']/div[1]"))
	private List<WebElement> domRoundTripReturnFlightDetailsLink;
	@FindBy(xpath = ("//ul[@class='tabFlightDetail']/li"))
	private List<WebElement> flightDetailsTabLink;
	@FindBy(xpath = ("//div[@class='sort-by-section ng-scope']/ul/li"))
	private List<WebElement> flightDetailsTabLinkForReturnFlight;
	@FindBy(xpath = ("//div[contains(@id,'DivOut')]"))
	private List<WebElement> oneGoFlight;
	@FindBy(xpath = ("//div[contains(@id,'DivIN')]"))
	private List<WebElement> returnFlight;
	//============================================================
	//RoundTrip International flight
	@FindBy(xpath=("//span[text()='Flight Detail']"))
	private List<WebElement> roundTripInternationalFlightDetailsLink;
	@FindBy(xpath=("//div[@class='sort-by-section ng-scope']/ul/li"))
	private List<WebElement> roundTripInternationalFlightDetailsTab;
	@FindBy(xpath=("//button[text()='Book Now']"))
	private List<WebElement> roundTripInternationalBookNowBtn;
	
	//============================================================
	@FindBy(xpath = ("//div[@id='BtnBookNow']"))
	private WebElement roundTripBookNowBtn;
	@FindBy(xpath = ("//div[@class='inp-b5']//span[text()='1']"))
	private WebElement noOfTravellers;
	// Below path for Review Page Flight Details
	@FindBy(xpath = ("//div[@class='fd-l']/div[1]/div[2]/div/div/div"))
	private WebElement FlightDetailsForOneWay;
	@FindBy(xpath = ("//div[@class='fd-l']/div[1]/div[2]"))
	private WebElement flightDetailsForRoundTrip;
	//WebElement For Multicity Route!!!
	@FindBy(xpath = ("//div[@class='row bor-b']/div[2]/div/div[2]/button[text()='Book Now']"))
	private List<WebElement> mulCityBookNowBtn;
	@FindBy(xpath=("//div[@id='divLoadFltDetails']/div[1]/div"))
	private List<WebElement> flightDetails;
	@FindBy(xpath=("//div[@class='fd-l']/div[7]/div[2]/div[1]"))
	private WebElement goodToKnowPoints;
	@FindBy(xpath=("//div[contains(@class,'m-info-tips m')]"))
	private WebElement importantInfo;
	public BookFlightPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}

	public void flightDetails(){
		for(int f=0;f<flightDetails.size();f++){
			String detailsOfMulticityFlight = flightDetails.get(f).getText();
		System.out.println("Selected Flight Details are given below!!! "+"  "+detailsOfMulticityFlight);
		}
		
	}
	public void goodToKnow(){
		String points = goodToKnowPoints.getText();
		System.out.println("Point to be Remember as given below :"+"  "+points);
		/*if(isImpInfo(importantInfo)){
			String importantInfoDetails = importantInfo.getText();
			System.out.println("Important Information about selected Flight \n:"+importantInfoDetails);
		}else{
			System.out.println("No important information available!!!");
		}*/
	}
	public boolean isImpInfo(WebElement importantInfo ){
		if(importantInfo.isDisplayed()){
			return true;
		}
		return false;
		
	}
	int sizeOfFlightDetails;

	public void compareTrips(int numberOfWays) throws InterruptedException {
		WaitStatementLib.iWait(2);
		if (numberOfWays == 0) {
			comp();
		} else if (numberOfWays == 1) {
			roundTripComp();
		}
		else if(numberOfWays == 2){
			BookMulCityFlight();
		}
	}

	int sizeOfDomFlightDetails;
	// method for fetching Flight Details for Domestic OneWay
	public void fareDetailsForDomesticOneWay() {
		Random flightDetails = new Random();
		sizeOfDomFlightDetails = flightDetails.nextInt(domFlightDetails.size());

		WebElement selectedDomFlightDetails = domFlightDetails.get(sizeOfDomFlightDetails);
		selectedDomFlightDetails.click();

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}

		int sizeOfFaresDetailstab = fetchingFlightFareDetails.size();
		for (int i = 0; i < sizeOfFaresDetailstab; i++) {
			fetchingFlightFareDetails.get(i).click();
			if (i == 0) {
				for (int k = 0; k < tabDetails0.size(); k++) {
					System.out.println(tabDetails0.get(k).getText());
					System.out.println("============================================================");
				}
			}

			else if (i == 1) {
				for (int l = 0; l < tabDetails1.size(); l++) {
					System.out.println(tabDetails1.get(l).getText());
					System.out.println("============================================================");
				}
			} else if (i == 2) {

				for (int j = 0; j < baggageTabDetails.size(); j++) {
					String baggageContent = baggageTabDetails.get(j).getText();
					System.out.println(baggageContent);
					System.out.println("============================================================");
				}
			} else {
				String cancellationText = canellationTabDetails.getText();
				System.out.println(cancellationText);
				System.out.println("============================================================");

			}
		}
	}

	int sizeOfIntlFlightDetails;

	public void fareDetailsForInternationalOneWay() throws InterruptedException {
		Random intlOneWayFlightDetails = new Random();
		sizeOfIntlFlightDetails = intlOneWayFlightDetails.nextInt(intlFlightDetail.size());
		WebElement selectedIntlFlightDetails = intlFlightDetail.get(sizeOfIntlFlightDetails);
		selectedIntlFlightDetails.click();

		Thread.sleep(1000);
		int sizeOfIntlFlightFaresDetailstab = intlFlightDetailTab.size();
		for (int i = 0; i < sizeOfIntlFlightFaresDetailstab; i++) {
			intlFlightDetailTab.get(i).click();

			if (i == 2) {
				List<WebElement> baggageTabInformationDetails = driver
						.findElements(By.xpath("//div[@class='li-mn ng-scope']/div[2]/div"));
				int sizeOfFlightDetails = baggageTabInformationDetails.size();
				for (int k = 0; k < sizeOfFlightDetails; k++) {
					System.out.println(baggageTabInformationDetails.get(k).getText());
					System.out.println("=======================================================");
				}

			}

			if (i == 3) {
				List<WebElement> IntlcancellationRule = driver
						.findElements(By.xpath("//div[@class='bood mg-btm']/div"));
				int sizeOfCancellation = IntlcancellationRule.size();
				for (int k = 0; k < sizeOfCancellation; k++) {
					String dataInRow = IntlcancellationRule.get(k).getText();
					System.out.println(dataInRow);
					System.out.println("=======================================================");

				}
			}

			else {
				List<WebElement> flightInformationTab = driver
						.findElements(By.xpath("//div[contains(@id,'divFlightDetailSec')]/div[2]/div/div"));
				int sizeOfFlightInfDiv = flightInformationTab.size();
				for (int m = 0; m < sizeOfFlightInfDiv; m++) {
					String textForFlightInf = flightInformationTab.get(m).getText();
					System.out.println(textForFlightInf);
					System.out.println("=======================================================");
				}

			}
		}

	}

	int sizeOfIntlRoundTripFlightDetails;
	public void fareDetailsForInternationalRoundTrip() throws InterruptedException {
		Random intlOneWayFlightDetails = new Random();
		sizeOfIntlRoundTripFlightDetails = intlOneWayFlightDetails.nextInt(roundTripInternationalFlightDetailsLink.size());
		WebElement selectedIntlRoundTripFlightDetails = roundTripInternationalFlightDetailsLink.get(sizeOfIntlRoundTripFlightDetails);
		//selectedIntlRoundTripFlightDetails.click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click()", selectedIntlRoundTripFlightDetails);

		Thread.sleep(1000);
		int sizeOfIntlRoundTripFlightFaresDetailstab = roundTripInternationalFlightDetailsTab.size();
		for (int i = 0; i < sizeOfIntlRoundTripFlightFaresDetailstab; i++) {
			roundTripInternationalFlightDetailsTab.get(i).click();

			if(i==1){
				String fareDetails = driver.findElement(By.xpath("//div[@class='fre ng-scope']")).getText();
				System.out.println(fareDetails);
				System.out.println("==============================================================");
			}
			if (i == 2) {
				 WebElement baggageTabRoundTripIntInformationDetails = driver
						.findElement(By.xpath("//div[@class='ba ng-scope']"));
				System.out.println(baggageTabRoundTripIntInformationDetails.getText());
				System.out.println("=======================================================");
			

			}

			if (i == 3) {
				 WebElement IntlRountTripcancellationRule = driver
						.findElement(By.xpath("//div[@class='bood mg-btm']"));
				String dataInRow=IntlRountTripcancellationRule.getText();
				System.out.println(dataInRow);
				System.out.println("=======================================================");
				
			}

			else {
				List<WebElement> flightInformationTab = driver
						.findElements(By.xpath("//div[contains(@id,'divFlightDetailSec')]/div[2]/div/div"));
				int sizeOfFlightInfDiv = flightInformationTab.size();
				for (int m = 0; m < sizeOfFlightInfDiv; m++) {
					String textForFlightInf = flightInformationTab.get(m).getText();
					System.out.println(textForFlightInf);
					System.out.println("=======================================================");
				}

			}
		}

	}

	Random domesticRoundTrip;
	int sizeOfOneGoFlight;

	public void fareDetailsForOneGoDomesticRoundTrip() {
		System.out.println("Going to fetch One Way Flight Details!!!");
		domesticRoundTrip = new Random();
		sizeOfOneGoFlight = domesticRoundTrip.nextInt(domRoundTripOneGoFlightDetailsLink.size());
		WebElement oneGoFlightDetails = domRoundTripOneGoFlightDetailsLink.get(sizeOfOneGoFlight);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click()", oneGoFlightDetails);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}

		int tabSizeForOneGoFlight = flightDetailsTabLink.size();
		for (int i = 0; i < tabSizeForOneGoFlight; i++) {
			WebElement tabPosition = flightDetailsTabLink.get(i);

			if (i > 0) {
				JavascriptExecutor js1 = (JavascriptExecutor) driver;
				js1.executeScript("arguments[0].click()", tabPosition);

			}

			if (i == 0) {
				WebElement flightInfText = driver
						.findElement(By.xpath("//div[contains(@id,'divFlightDetailSec')]/div[2]/div"));
				System.out.println("Flight Information for Selected Flight : ");
				System.out.println(flightInfText.getText());
				System.out.println("============================================================================");
			} else if (i == 1) {

				WebElement fareDetailsTabText = driver
						.findElement(By.xpath("//div[contains(@id,'divFlightDetailSec')]/div[2]/div/div/div"));
				System.out.println("Fare Details for Selected Flight : ");
				System.out.println(fareDetailsTabText.getText());
				System.out.println("============================================================================");
			} else if (i == 2) {

				WebElement baggageInfSubTabName = driver
						.findElement(By.xpath("//div[contains(@id,'divFlightDetailSec')]/div[2]/div"));

				String baggageInfText = baggageInfSubTabName.getText();
				System.out.println("Baggage Details for Selected Flight : ");
				System.out.println(baggageInfText);
				System.out.println("==========================================================================");
			}

			else {

				List<WebElement> cancellationTab = driver.findElements(By.xpath("//div[@class='bood mg-btm']"));
				String cancelleationRuleTabText = cancellationTab.get(0).getText();
				System.out.println("Cancellation rule for Selected Flight : ");
				System.out.println(cancelleationRuleTabText);
				System.out.println("===============================================================================");

			}
		}

	}

	int sizeOfReturnFlight;

	public void fareDetailsForRetFlightDomesticRoundTrip() {
		System.out.println("Going to fetch return Flight Details!!!");
		Random domRounfTrips = new Random();
		sizeOfReturnFlight = domRounfTrips.nextInt(domRoundTripReturnFlightDetailsLink.size());
		WebElement retFlightDetails = domRoundTripReturnFlightDetailsLink.get(sizeOfReturnFlight);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click()", retFlightDetails);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e2) {

			e2.printStackTrace();
		}

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e1) {

			e1.printStackTrace();
		}

		int tabSizeForRetFlight = flightDetailsTabLinkForReturnFlight.size();
		for (int r = 0; r < tabSizeForRetFlight; r++) {

			WebElement tabPosition1 = flightDetailsTabLinkForReturnFlight.get(r);
			if (r > 0) {
				JavascriptExecutor js2 = (JavascriptExecutor) driver;
				js2.executeScript("arguments[0].click()", tabPosition1);

			}

			if (r == 0) {
				WebElement flightInfText = driver
						.findElement(By.xpath("//div[contains(@id,'divFlightDetailSec')]/div[2]/div"));
				System.out.println("Flight Information for Selected Flight : ");
				System.out.println(flightInfText.getText());
				System.out.println("============================================================================");
			} else if (r == 1) {
				WebElement fareDetailsTabText = driver
						.findElement(By.xpath("//div[contains(@id,'divFlightDetailSec')]/div[2]/div/div/div"));
				System.out.println("Fare Details for Selected Flight : ");
				System.out.println(fareDetailsTabText.getText());
				System.out.println("============================================================================");
			} else if (r == 2) {
				WebElement baggageInfSubTabName = driver
						.findElement(By.xpath("//div[contains(@id,'divFlightDetailSec')]/div[2]/div"));

				String baggageInfText = baggageInfSubTabName.getText();
				System.out.println("Baggage Details for Selected Flight : ");
				System.out.println(baggageInfText);
				System.out.println("==========================================================================");

			} else {
				List<WebElement> cancellationTab = driver.findElements(By.xpath("//div[@class='bood mg-btm']"));
				String cancelleationRuleTabText = cancellationTab.get(0).getText();
				System.out.println("Cancellation rule for Selected Flight : ");
				System.out.println(cancelleationRuleTabText);
				System.out.println("===============================================================================");
			}
		}
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}

	}

	public void comp() throws InterruptedException {
		WaitStatementLib.iWaitForSecs(driver, 10);
		String pageTitle = driver.getTitle();
		System.out.println(pageTitle);
		if (pageTitle.trim().contains("InternationalOwView2")) {
			try {
				fareDetailsForInternationalOneWay();
				interButtons.get(sizeOfIntlFlightDetails).click();
				Thread.sleep(1000);
				detailsOfOneWayFlight();
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}

		else {
			try {

				// calling method because fetching domestic flight flight
				// details
				fareDetailsForDomesticOneWay();
				domButtons.get(sizeOfDomFlightDetails).click();
				Thread.sleep(1000);
				detailsOfOneWayFlight();
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}

	}

	public void clickingGoingFlights() {
		try {

			fareDetailsForOneGoDomesticRoundTrip();
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver, 30);
			Thread.sleep(5000);
			WebElement goFlight = oneGoFlight.get(sizeOfOneGoFlight);
			Thread.sleep(5000);
			WebElement oneGo = wait.until(ExpectedConditions.elementToBeClickable(goFlight));
			Thread.sleep(5000);
			JavascriptExecutor js2 = (JavascriptExecutor) driver;
			js2.executeScript("arguments[0].click()", oneGo);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void clickingReturningFlights() {
		try {
			Thread.sleep(2000);
			fareDetailsForRetFlightDomesticRoundTrip();
			WebElement retFlight = returnFlight.get(sizeOfReturnFlight);
			Thread.sleep(1000);
			JavascriptExecutor js2 = (JavascriptExecutor) driver;
			js2.executeScript("arguments[0].click()", retFlight);
			Thread.sleep(1000);
			roundTripBookNowBtn.click();
			Thread.sleep(2000);
			detailsOfRoundTripFlight();

		} catch (Exception e) {
			e.printStackTrace();

		}

	}

	public void detailsOfOneWayFlight() {
		try {
			String detailsOfSelectedFlight = FlightDetailsForOneWay.getText();
			System.out.println("Details of selected Flights are:  " + detailsOfSelectedFlight);
		} catch (Exception e) {
			e.printStackTrace();

		}

	}

	public void detailsOfRoundTripFlight() {
		String detailsOfSelectedRoundTripFlight = flightDetailsForRoundTrip.getText();
		System.out.println(detailsOfSelectedRoundTripFlight);
		System.out.println("==========================================================================");
	}

	public boolean isOneGoFlight(List<WebElement> oneGoFlight) {
		try {
			if (oneGoFlight.size() > 0) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;

	}

	public boolean isReturnFlight(List<WebElement> returnFlight) {
		try {
			if (returnFlight.size() > 0) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public void roundTripComp() {
		String roundTriptDomPageTitle = driver.getTitle();
		System.out.println("Searched url is: " + roundTriptDomPageTitle);
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e1) {

			e1.printStackTrace();
		}

		if (roundTriptDomPageTitle.contains("RoundTrip Lowest Airfare")) {
			try {
				if (isOneGoFlight(oneGoFlight) && isReturnFlight(returnFlight)) {

					clickingGoingFlights();
					clickingReturningFlights();
				} else {

					System.err.println("OOps!!! Flight not available for Your Searched!!!");
					Assert.fail("Flight Not Found!!!");
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		else {
			try {
				fareDetailsForInternationalRoundTrip();
			} catch (InterruptedException e1) {
			
				e1.printStackTrace();
			}
			//List<WebElement> intlBookNowBtn = driver.findElements(By.xpath("//button[text()='Book Now']"));
			try {
				Thread.sleep(3000);
				//Random ra6 = new Random();

				//roundTripInternationalBookNowBtn.get(ra6.nextInt(intlBookNowBtn.size()) - 1).click();
				WebElement roundTripIntlFlight = roundTripInternationalBookNowBtn.get(sizeOfIntlRoundTripFlightDetails);
				JavascriptExecutor js2 = (JavascriptExecutor) driver;
				js2.executeScript("arguments[0].click()", roundTripIntlFlight);
				Thread.sleep(2000);
				
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}

	}
	  public void BookMulCityFlight(){ 
	  Random ra5 = new Random(); 
	  int mulCityFlight = ra5.nextInt(mulCityBookNowBtn.size());
	  WaitStatementLib.iWait(2); 
	  System.out.println("Index of choosen flights  : " + mulCityFlight); 
	  WaitStatementLib.iWait(2);
	  mulCityBookNowBtn.get(mulCityFlight).click();
	  WaitStatementLib.iWait(10);
	  System.out.println("=====================================================================================================================");
	  flightDetails();
	  System.out.println("=====================================================================================================================");
	  goodToKnow();
	  System.out.println("=====================================================================================================================");

	   }
	 

	// For handling exception
	/*
	 * public boolean isAlertPresent() { try { Alert a1 = new
	 * WebDriverWait(driver, 10).until(ExpectedConditions.alertIsPresent()); if
	 * (a1 != null) { System.out.println("Alert is present");
	 * driver.switchTo().alert().accept(); clickingGoingFlights();
	 * clickingReturningFlights(); } } catch (Exception e) {
	 * e.printStackTrace(); // System.err.println("Alert isn't present!!"); }
	 * return false;
	 * 
	 * }
	 */
}
