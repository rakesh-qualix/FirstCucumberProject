package com.easemytrip.pageobjects;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.easemytrip.generic.WaitStatementLib;

public class SearchFlightsPage {
	WebDriver driver;
	int numberOfWays;

	public int getNumberOfWays() {
		return numberOfWays;
	}

	public void setNumberOfWays(int numberOfWays) {
		this.numberOfWays = numberOfWays;
	}

	@FindBy(xpath = ("//div[@class='one-rou']/ul/li"))
	private List<WebElement> ways;
	@FindBy(xpath = ("//input[@id='FromSector_show']"))
	private WebElement fromCityName;
	@FindBy(xpath = ("//input[@id='Editbox13_show']"))
	private WebElement toCityName;
	@FindBy(xpath = ("//input[@id='ddate']"))
	private WebElement departureDate;
	@FindBy(xpath = ("//div[contains(@class,'month')]//div"))
	private List<WebElement> listOfMonth;
	@FindBy(xpath = ("//input[@id='rdate']"))
	private WebElement returnDate;
	@FindBy(xpath = ("//a[@class='dropbtn_n']"))
	private List<WebElement> travellerAndClass;
	@FindBy(xpath = ("//div[@class='search_bg']/div[1]/div[6]/input"))
	private WebElement searchBtn;
	@FindBy(xpath = ("//a[text()='Modify Search & Try Again']"))
	public WebElement modifyAndSearch;
	// handling Frame PopUp
	@FindBy(xpath = ("//div[@id='container_id']"))
	private WebElement frameId;
	@FindBy(xpath = ("//input[@id='st_textbox_1']"))
	private WebElement subscriberEmailId;
	@FindBy(xpath = ("//input[@id='st_textbox_2']"))
	private WebElement subscriberMobileNo;
	@FindBy(xpath = (""))
	private WebElement subscribeBtn;
	@FindBy(xpath = ("//a[@id='close_btn']"))
	private WebElement frameHandling;
	// storing WebElement for Multicity
	@FindBy(xpath = ("//span[@class='checkmark']"))
	private WebElement mulCityRoute;
	@FindBy(xpath = ("//div[contains(@id,'sector-sec')]/div[position()<4]"))
	private List<WebElement> mulElement;
	@FindBy(xpath = ("//div[@id='ui-datepicker-div']/table/tbody/tr/td[@data-handler='selectDay']"))
	private List<WebElement> mulDate;
	@FindBy(xpath = ("//div[@class='s_col_v4']"))
	private WebElement mulSearchBtn;

	public SearchFlightsPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}

	public void mulDateSelection() {
		Random date = new Random();
		int selectedDate = date.nextInt(mulDate.size());
		WebElement choosenDate = mulDate.get(selectedDate);
		if (i == 2) {
			System.out.println("Selected Date 1 is :" + " " + choosenDate.getAttribute("textContent") + "Feb" + "2019");
		} else if (i == 5) {
			System.out.println("Selected Date 2 is :" + " " + choosenDate.getAttribute("textContent") + "Feb" + "2019");
		}
		choosenDate.click();
	}

	ArrayList<String> list = new ArrayList<String>();
	ArrayList<String> list1 = new ArrayList<String>();

	public void city() {
		List<WebElement> cities = driver.findElements(
				By.xpath("//div[contains(@id,'sector-sec')][position()<3]/div/div/div/div/div/div/ul/li"));
		list.clear();
		// ================================================
		int si = cities.size();
		for (int si1 = 0; si1 < si; si1++) {

			String citiStore = cities.get(si1).getText();
			if (!citiStore.isEmpty()) {
				list.add(citiStore);
			}

		}

	}

	public void citySelection() {
		city();
		list1.clear();
		for (int l = 0; l < list.size(); l++) {
			String cities = list.get(l);
			String[] splitedDep = cities.split("\\(");
			int splitDep1 = splitedDep[0].length();
			String dep = splitedDep[0].trim().substring(0, splitDep1);
			list1.add(dep);
		}

	}

	int i;
	String srcAndDest;
	public void searchMulFlight() throws InterruptedException {
		for (i = 0; i < 6; i++) {
			WebElement element = mulElement.get(i);
			if (i == 3) {
				if (i == 3) {
					System.out.println("Selected Departure City2 :" + " " + srcAndDest);
				}
				continue;
			}
			element.click();

			if (i == 0 || i == 1 || i == 3 || i == 4) {
				
				citySelection();
				Random sector = new Random();
				int selectedSector = sector.nextInt(list1.size());
				 srcAndDest = list1.get(selectedSector);
				if (i == 0) {
					System.out.println("Selected Departure City1 :" + " " + srcAndDest);
				} else if (i == 1) {
					System.out.println("Selected Destination City1 :" + " " + srcAndDest);
				}  else if (i == 4) {
					System.out.println("Selected Destination City2 :" + " " + srcAndDest);
				}

				try {
					Actions actions = new Actions(driver);
					actions.moveToElement(element);
					actions.click();
					actions.sendKeys(srcAndDest);
					if (srcAndDest.equalsIgnoreCase("Goa")) {
						actions.build().perform();
						actions.sendKeys(Keys.ARROW_DOWN);
						Thread.sleep(2000);
						actions.build().perform();
						actions.sendKeys(Keys.ENTER);
						Thread.sleep(1000);
						actions.build().perform();
					} else {
						actions.build().perform();
						actions.sendKeys(Keys.ENTER);
						Thread.sleep(2000);
						actions.build().perform();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			} else if (i == 2 || i == 5) {
				mulDateSelection();
			}
			try {
				Thread.sleep(2000);

			} catch (InterruptedException e) {

				e.printStackTrace();
			}

		}
		mulSearchBtn.click();
		if (isAlertPresent()) {
			Thread.sleep(2000);
			searchMulFlight();
		} 
		Thread.sleep(5000);
		
	}

	// =======================================================================
	// List of Airports
	// List<String> listOfAirports =
	// Arrays.asList("AAR","ABD","AEH","ABZ","ABR","ABJ","ABI","AUH","SIN","DXB","VLI","ADL","ADE","BKK");
	List<String> listOfAirports = Arrays.asList("MAA", "BOM", "IXU", "COK", "AMD", "AJL", "AKD", "IXD", "BLR", "LKO",
			"GAU", "IXC", "COH", "CDP", "DHM", "GAY", "GOP", "JGA", "GWL", "JLR", "SHL", "BEK", "BUP", "BHO", "PAB",
			"IXR");
	/*
	 * List<String> listOfAirports = Arrays.asList("ATL", "MYQ", "SIN", "VTZ",
	 * "DEL", "BOM", "BLR", "MAA", "CCU", "HYD", "COK", "IXC", "AMD", "PNQ",
	 * "SXR", "GOI", "GAU", "TRV", "LKO", "ATQ", "IXE", "IDR", "CCJ", "CJB",
	 * "JAI", "NAG", "VNS", "PAT", "BDQ", "DED", "IXM", "IXB", "IXJ", "TRZ",
	 * "IXA", "BBI", "IMF", "DIB", "IXR", "IXZ", "JDH", "UDR", "IXL", "BHO",
	 * "STV", "GAY", "IXU", "RAJ", "IXS", "HJR", "AJL", "HBX", "RJA", "BHJ",
	 * "BZL", "JRH", "JLR", "AGX", "IXD", "DHM", "AGR", "PGH", "IXG", "BHU",
	 * "PBD", "GOP", "KUU", "GWL", "BPM", "DMU", "JGA", "SHL", "KNU", "LUH",
	 * "RPR", "PEK", "DXB", "HND", "LAX", "ORD", "LHR", "HKG", "PVG", "CDG",
	 * "AMS", "DFW", "CAN", "FRA", "IST", "CGK", "TIR", "ICN", "DEN", "BKK",
	 * "JFK", "KUL", "SFO", "MAD", "CTU", "LAS", "BCN", "YYZ");
	 */

	public void cityFrom() throws Exception {
		try {
			fromCityName.click();
			Random airport = new Random();
			// @SuppressWarnings("unused")

			int randomAirportIndex = airport.nextInt(listOfAirports.size());
			// String cityFrom = listOfAirports.get(4);
			String cityFrom = listOfAirports.get(randomAirportIndex);
			System.out.println("Selected source city :" + " " + cityFrom);

			Thread.sleep(1000);

			fromCityName.sendKeys(cityFrom);

			Thread.sleep(2000);
			// WebDriverWait wait = new WebDriverWait(driver, 10);
			// wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("FromSector_show")));
			// fromCityName.sendKeys(Keys.ARROW_DOWN);
			fromCityName.sendKeys(Keys.ENTER);
			// fromCityName.sendKeys(Keys.TAB);
			// Thread.sleep(2000);
			// WaitStatementLib.iWait(2);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void toCity() throws Exception {
		toCityName.click();
		Random airport = new Random();
		// @SuppressWarnings("unused")
		int randomAirportIndex = airport.nextInt(listOfAirports.size());
		// String cityTo = listOfAirports.get(6);
		String cityTo = listOfAirports.get(randomAirportIndex);
		System.out.println("Selected Destination city :" + " " + cityTo);

		toCityName.sendKeys(cityTo);
		Thread.sleep(2000);
		// WebDriverWait wait = new WebDriverWait(driver, 10);
		// wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Editbox13_show")));
		// toCityName.sendKeys(Keys.ARROW_DOWN);
		toCityName.sendKeys(Keys.ENTER);
		// toCityName.sendKeys(Keys.TAB);
		Thread.sleep(1000);
		// WaitStatementLib.iWait(2);

	}

	public void depDate() throws Exception {
		departureDate.click();
		// driver.findElement(By.xpath("//div[@id='dvcalendar']/div/div/div/div[@class='days']/ul//li[@class='active-date']")).click();
		Thread.sleep(2000);
		List<WebElement> dDates = driver.findElements(
				By.xpath("//div[@id='dvcalendar']/div/div/div/div[@class='days']/ul//li[@class!='old-dt']"));
		int sizeOfDateList = dDates.size();
		Random ra3 = new Random();
		int randomdate = ra3.nextInt(sizeOfDateList);
		WebElement selectedDate = dDates.get(randomdate);
		Thread.sleep(1000);
		selectedDate.click();
	}

	public void returnDate() {
		returnDate.click();
		driver.findElement(By.xpath("//img[@id='img2Nex']")).click();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("rdate")));
		List<WebElement> retDates = driver.findElements(
				By.xpath("//div[@id='dvcalendar']/div/div/div/div[@class='days']/ul//li[@class!='old-dt']"));
		Random ra4 = new Random();
		// int sizeOfTheRetDate = ra4.nextInt(retDates.size() - 1);
		retDates.get(ra4.nextInt(retDates.size() - 1)).click();
		WaitStatementLib.iWait(2);
	}

	public int selectingWays() throws Exception {
		// Thread.sleep(5000);
		// WaitStatementLib.iWait(10);
		numberOfWays = returnways();
		setNumberOfWays(numberOfWays);
		if (numberOfWays == 2) {
			System.out.println("Selected Way is Multicity Route!!!");
			mulCityRoute.click();
			Thread.sleep(2000);
			searchMulFlight();
		}

		else {
			WebElement wayChoosen = ways.get(numberOfWays);
			// Thread.sleep(2000);
			wayChoosen.click();
			// Thread.sleep(2000);
			System.out.println("Selecetd way is " + wayChoosen.getText());
			System.out.println("========================================");
		}
		if (numberOfWays == 0) {
			// Thread.sleep(1000);
			cityFrom();
			toCity();
			depDate();
			// travelersDetails();
			clickOnSearch();

		} else if (numberOfWays == 1) {
			// Thread.sleep(1000);
			cityFrom();
			toCity();
			depDate();
			returnDate();
			travelersDetails();//
			clickOnSearch();

			Thread.sleep(5000);

		}

		return numberOfWays;
	}

	public int returnways() {
		Random rand = new Random();
		List<Integer> givenList = Arrays.asList(0, 1, 2);
		int randomElement = 0;
		int numberOfElements = 1;
		int numberOfElements1 = 2;

		// for (int i = 0; i < numberOfElements1; i++) {
		int randomIndex = rand.nextInt(givenList.size());
		// randomElement = givenList.get(randomIndex);
		// randomElement = givenList.get(rand.nextInt(givenList.size()));
		randomElement = givenList.get(2);
		// }
		return randomElement;
	}

	public void travelersDetails() {
		travellerAndClass.get(0).click();
		WaitStatementLib.iWait(1);
		List<WebElement> plus = driver.findElements(
				By.xpath("//div[@id='myDropdown_n']/div/div[@class='main_dv']/div[2]/div/div[3]/input[@value='+']"));
		WebElement sizeOfPlusSignForAdult = plus.get(0);
		// WebElement sizeOfPlusSignForChid = plus.get(1);
		// WebElement sizeOfPlusSignForInfant = plus.get(2);
		for (int i = 1; i <= 1; i++) {
			sizeOfPlusSignForAdult.click();
			// sizeOfPlusSignForChid.click();
			// sizeOfPlusSignForInfant.click();

		}
		driver.findElement(By.xpath("//div[@id='myDropdown_n']/div/a[text()='Done']")).click();
		WaitStatementLib.iWait(2);
	}

	public void clickOnSearch() throws Exception {
		try {
			searchBtn.click();
			// WaitStatementLib.iWait(20);
			// Thread.sleep(5000);
			if (isAlertPresent()) {
				// Thread.sleep(2000);
				selectingWays();
			} else if (modifyAndSearch.isDisplayed()) {
				Thread.sleep(2000);
				modifyAndSearch.click();
				WaitStatementLib.iWait(2);
				// System.out.println();
				System.err.println("Flight not found for this route and choosen date!!!");
				selectingWays();
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public boolean isAlertPresent() {
		try {
			Alert a = new WebDriverWait(driver, 10).until(ExpectedConditions.alertIsPresent());

			if (a != null) {
				System.err.println("Alert is present");
				// Thread.sleep(2000);
				driver.switchTo().alert().accept();
				// Thread.sleep(2000);
				selectingWays();
				return true;
			}

			else {
				throw new Throwable();

			}
		} catch (Throwable e) {
			// System.err.println("Alert isn't present!!");
			return false;
		}

	}
}
